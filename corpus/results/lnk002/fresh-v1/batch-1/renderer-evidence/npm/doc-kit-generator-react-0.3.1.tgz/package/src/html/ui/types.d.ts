import { GlobalConfiguration } from '@doc-kit/core/utils/configuration/types';
import { MetadataEntry } from '@doc-kit/core/generators/metadata/types';
import { Configuration } from '../types';
import { SemVer } from 'semver';

declare module '#theme/config' {
  // From global configuration
  export const repository: GlobalConfiguration['repository'];
  export const input: GlobalConfiguration['input'];
  export const ignore: GlobalConfiguration['ignore'];
  export const output: GlobalConfiguration['output'];
  export const minify: GlobalConfiguration['minify'];
  export const baseURL: GlobalConfiguration['baseURL'];
  export const ref: GlobalConfiguration['ref'];

  // From web configuration
  export const templatePath: Configuration['templatePath'];
  export const title: Configuration['title'];
  export const useAbsoluteURLs: Configuration['useAbsoluteURLs'];
  export const navigation: Configuration['navigation'];

  // From config generation
  export const version: SemVer;
  export const versions: Array<{
    url: string;
    label: string;
    major: number;
  }>;
  export const editURL: string;
  export const pages: Array<[string, string]>;
  export const chunks: Record<string, ChunkGroup>;
  export const languageDisplayNameMap: Map<string[], string>;
  export const remoteConfigUrl: string;
  export const server: boolean;
}

// A module's section pages, nested by heading depth (see `section-pages`)
export type ChunkSection = {
  label: string;
  path: string;
  items?: Array<ChunkSection>;
};

export type ChunkGroup = {
  label: string;
  items: Array<ChunkSection>;
};

// Omit Primitives from Metadata
type Primitive = string | number | boolean | symbol | bigint | null | undefined;
type OnlyPrimitives<T> = {
  [K in keyof T as T[K] extends Primitive ? K : never]: T[K];
};

export type SerializedMetadata = OnlyPrimitives<MetadataEntry>;
