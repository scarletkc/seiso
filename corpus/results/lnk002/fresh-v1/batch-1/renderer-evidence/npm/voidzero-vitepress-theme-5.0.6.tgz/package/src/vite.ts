import { VoidZeroTheme, themeContextKey } from "./";
import type { Theme } from "vitepress";

// inject project variant assets
import logoDark from "@assets/logos/vite-dark.svg";
import logoLight from "@assets/logos/vite-light.svg";
import footerBg from "@assets/vite/footer-background.jpg";
import monoIcon from "@assets/icons/vite-mono.svg";

export default {
  ...VoidZeroTheme,
  enhanceApp(ctx) {
    ctx.app.provide(themeContextKey, {
      logoDark,
      logoLight,
      logoAlt: "Vite",
      footerBg,
      monoIcon,
    });
    VoidZeroTheme.enhanceApp(ctx)
  },
} satisfies Theme;
