export interface Sponsor {
  name: string
  img: string
  url: string
  hasDark?: true
}

export type SponsorSize = 'big' | 'medium' | 'small' | 'avatar'

export interface SponsorTier {
  tier: string
  size: SponsorSize
  items: Sponsor[]
}
