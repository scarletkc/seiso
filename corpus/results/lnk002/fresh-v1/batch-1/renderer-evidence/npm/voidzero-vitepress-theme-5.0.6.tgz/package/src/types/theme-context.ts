import { InjectionKey } from "vue";

// asset injection for different project variants
export interface ThemeContext {
  // header
  /**
   * "@assets/logos/[project]-dark.svg"
   */
  logoDark: string;
  /**
   * "@assets/logos/[project]-light.svg"
   */
  logoLight: string;
  /**
   * @string
   */
  logoAlt: string;

  // footer
  /**
   * "@assets/[project]/footer-background.jpg"
   */
  footerBg: string;
  
  // banner
  /**
   * "@assets/icons/[project]-mono.svg"
   */
  monoIcon: string
}

export const themeContextKey: InjectionKey<ThemeContext> =
  "theme-context-key" as any; // using symbol breaks with HMR
