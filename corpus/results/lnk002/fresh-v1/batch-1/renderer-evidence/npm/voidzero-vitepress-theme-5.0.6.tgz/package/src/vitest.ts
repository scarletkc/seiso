import { VoidZeroTheme, themeContextKey } from "./";
import type { Theme } from "vitepress";

// inject project variant assets
import logoDark from "@assets/logos/vitest-dark.svg";
import logoLight from "@assets/logos/vitest-light.svg";
import footerBg from "@assets/vitest/footer-background.jpg";
import monoIcon from "@assets/icons/vitest-mono.svg";

export default {
  ...VoidZeroTheme,
  enhanceApp(ctx) {
    ctx.app.provide(themeContextKey, {
      logoDark,
      logoLight,
      logoAlt: "Vitest",
      footerBg,
      monoIcon,
    });
    VoidZeroTheme.enhanceApp(ctx)
  },
} satisfies Theme;
