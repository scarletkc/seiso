/**
 * Extended theme configuration types for VoidZero VitePress theme
 */

import type { DefaultTheme } from 'vitepress/theme'

/**
 * Icon option — a single string for both modes, or per-mode variants
 */
export type IconOption = string | { light: string; dark: string }

/**
 * Grid size options for sponsor display
 */
export type GridSize = 'xmini' | 'mini' | 'small' | 'medium' | 'big'

/**
 * Sponsor item
 */
export interface Sponsor {
  name: string
  img: string
  url: string
}

/**
 * Footer navigation link
 */
export interface FooterLink {
  text: string
  link: string
}

/**
 * Footer navigation column
 */
export interface FooterColumn {
  title: string
  items: FooterLink[]
}

/**
 * Footer social link
 */
export interface FooterSocialLink {
  icon: string
  link: string
  label?: string
}

/**
 * Extended footer configuration (extends VitePress DefaultTheme.Footer)
 */
export interface FooterConfig extends DefaultTheme.Footer {
  nav?: FooterColumn[]
  social?: FooterSocialLink[]
}

/**
 * Sponsor tier configuration for VPSponsors and VPDocAsideSponsors
 */
export interface SponsorTier {
  tier: string
  size?: GridSize
  items: Sponsor[]
}

/**
 * Top banner configuration for OSS variants
 */
export interface BannerConfig {
  /** id for dismissed local storage check */
  id: string
  /** Banner text content */
  text: string
  /** URL the banner links to */
  url: string
  /** Optional: Link target (defaults to '_blank' for external URLs) */
  target?: '_self' | '_blank'
  /** Optional: Override the banner icon (defaults to the theme mono icon) */
  icon?: 'vite' | 'vitest' | 'rolldown' | 'oxc' | 'viteplus'
}

/**
 * VoidZero theme configuration extending VitePress default
 */
export interface VoidZeroThemeConfig extends DefaultTheme.Config {
  variant?: 'voidzero' | 'viteplus' | 'vite' | 'vitest' | 'rolldown' | 'oxc'
  footer?: FooterConfig
  banner?: BannerConfig
}

declare module 'vitepress' {
  namespace DefaultTheme {
    // Extend Footer to include nav and social
    interface Footer {
      nav?: FooterColumn[]
      social?: FooterSocialLink[]
    }

    // Add variant and banner to Config
    interface Config {
      variant?: 'voidzero' | 'viteplus' | 'vite' | 'vitest' | 'rolldown' | 'oxc'
      banner?: BannerConfig
    }

    // Add icon support to nav and sidebar items
    interface NavItemWithLink {
      icon?: IconOption
    }

    interface NavItemWithChildren {
      icon?: IconOption
    }

    // Note: SidebarItem is a type alias (not interface) so it can't be
    // augmented. Sidebar icon support works via runtime casting in
    // VPSidebarItem.vue — the icon property is passed through config objects.
  }
}
