'use strict';

import { basename, join } from 'node:path';

import getConfig from '@doc-kit/core/utils/configuration/index.mjs';
import { populate } from '@doc-kit/core/utils/configuration/templates.mjs';
import { withExt, writeFile } from '@doc-kit/core/utils/file.mjs';

import { checkIndirectReferences } from './utils/checkIndirectReferences.mjs';
import { extractExports } from './utils/extractExports.mjs';
import { findDefinitions } from './utils/findDefinitions.mjs';

/**
 * Generates the `apilinks.json` file.
 *
 * @type {import('./types').Generator['generate']}
 */
export async function generate(input) {
  const config = getConfig('api-links');
  /**
   * @type Record<string, string>
   */
  const definitions = {};

  input.forEach(program => {
    /**
     * Mapping of definitions to their line number
     *
     * @type {Record<string, number>}
     * @example { 'someclass.foo': 10 }
     */
    const nameToLineNumberMap = {};

    const fileName = basename(program.path);
    const baseName = withExt(fileName);

    const exports = extractExports(program, baseName, nameToLineNumberMap);

    findDefinitions(program, baseName, nameToLineNumberMap, exports);

    checkIndirectReferences(program, exports, nameToLineNumberMap);

    const fullGitUrl = populate(config.sourceURL, {
      ...config,
      fileName,
    });

    // Add the exports we found in this program to our output
    Object.keys(nameToLineNumberMap).forEach(key => {
      const lineNumber = nameToLineNumberMap[key];

      definitions[key] = `${fullGitUrl}#L${lineNumber}`;
    });
  });

  if (config.output) {
    const out = join(config.output, 'apilinks.json');

    await writeFile(
      out,
      config.minify
        ? JSON.stringify(definitions)
        : JSON.stringify(definitions, null, 2)
    );
  }

  return definitions;
}
