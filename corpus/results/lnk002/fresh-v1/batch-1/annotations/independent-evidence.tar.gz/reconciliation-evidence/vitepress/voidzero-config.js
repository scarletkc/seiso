import { resolve } from "path";
import tailwindcss from "@tailwindcss/vite";

const __dirname = import.meta.dirname;

const aliases = {
  "@assets": resolve(__dirname, "src/assets"),
  "@components": resolve(__dirname, "src/components"),
  "@vp-default": resolve(__dirname, "src/components/vitepress-default"),
  "@vp-composables": resolve(
    __dirname,
    "src/composables/vitepress-default"
  ),
  "@vp-support": resolve(__dirname, "src/support/vitepress-default"),
};

export function extendConfig(c) {
  const config = c;

  // inject banner dismissal inline script in head
  // so that the dismissed class is added before CSS is loaded
  const bannerId = config.themeConfig.banner?.id;
  if (bannerId) {
    config.head ??= [];
    config.head.unshift([
      "script",
      {},
      `if (localStorage.getItem("banner-dismissed-${bannerId}") === 'true')
        document.documentElement.classList.add("banner-dismissed")`,
    ]);
  }

  const v = (config.vite ??= {});

  // inject fs allow so this can be linked locally
  v.server ??= {}
  v.server.fs ??= {}
  v.server.fs.allow ??= []
  v.server.fs.allow.push(__dirname)

  // add riv file asset include
  const a = (v.assetsInclude ??= []);
  if (!Array.isArray(a)) {
    v.assetsInclude = [a, "**/*.riv"];
  } else {
    a.push("**/*.riv");
  }

  // inject tailwind plugin
  v.plugins ??= [];
  v.plugins.unshift(tailwindcss());

  // avoid including @docsearch/css if using local search
  if (c.themeConfig?.search?.provider === 'local') {
    v.plugins.unshift({
      name: 'remove-docsearch-css',
      load: {
        filter: { id: '**/@docsearch/css/dist/style.css' },
        handler: () => ''
      }
    })
  }

  // inject alias
  v.resolve ??= {};
  const al = (v.resolve.alias ??= {});
  if (Array.isArray(al)) {
    for (const key in aliases) {
      al.push({
        find: key,
        replacement: aliases[key]
      })
    }
  } else {
    Object.assign(v.resolve.alias, aliases);
  }

  const pkg = "@voidzero-dev/vitepress-theme";

  // inject optimize include / exclude
  v.optimizeDeps ??= {};
  v.optimizeDeps.include ??= [];
  v.optimizeDeps.include.push(`${pkg} > @rive-app/canvas-lite`);
  v.optimizeDeps.exclude ??= [];
  v.optimizeDeps.exclude.push(pkg);

  // inject ssr no-external
  v.ssr ??= {};
  const e = (v.ssr.noExternal ??= []);
  if (!Array.isArray(e)) {
    if (e !== true) v.ssr.noExternal = [e, pkg];
  } else {
    e.push(pkg);
  }

  return c;
}
