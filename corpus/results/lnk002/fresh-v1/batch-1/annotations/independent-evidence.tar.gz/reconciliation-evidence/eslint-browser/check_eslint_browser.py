import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright
out=Path('/tmp/seiso-author-lnk002/eslint-browser');out.mkdir(exist_ok=False)
url='https://github.com/eslint/eslint/blob/d166567901e09940c1de4ad0e95d572eeab5c927/README.md'
receipt={'checked_at':datetime.now(timezone.utc).isoformat(),'certificate_verification':True,'commit':'d166567901e09940c1de4ad0e95d572eeab5c927','viewport':{'width':1280,'height':800},'cases':[]}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);receipt['browser_version']=browser.version
 for case,fragment in [('baseline',''),('technology-sponsors','#technology-sponsors'),('missing','#seiso-missing-fragment-control')]:
  page=browser.new_page(viewport=receipt['viewport']);assets=[];failures=[]
  page.on('response',lambda r:assets.append({'url':r.url,'status':r.status}) if 'github.githubassets.com' in r.url else None)
  page.on('requestfailed',lambda r:failures.append({'url':r.url,'failure':r.failure}))
  response=page.goto(url+fragment,wait_until='domcontentloaded',timeout=30000)
  page.wait_for_selector('article.markdown-body #user-content-technology-sponsors');page.wait_for_function('() => document.styleSheets.length > 10');page.wait_for_timeout(3500)
  measurement=page.evaluate("""() => {const anchor=document.querySelector('article.markdown-body #user-content-technology-sponsors');const heading=anchor.parentElement;return {hash:location.hash,scroll_y:scrollY,heading_top:heading.getBoundingClientRect().top,heading_document_y:heading.getBoundingClientRect().top+scrollY,heading_html:heading.outerHTML,stylesheet_count:document.styleSheets.length};}""")
  html=page.content().encode();(out/(case+'.html.gz')).write_bytes(__import__('gzip').compress(html,mtime=0));page.screenshot(path=str(out/(case+'.png')))
  result={'case':case,'url':page.url,'status':response.status,'measurement':measurement,'assets':assets,'request_failures':failures,'dom_sha256':hashlib.sha256(html).hexdigest()};receipt['cases'].append(result);(out/'browser.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='assets'}),flush=True);page.close()
 browser.close()
