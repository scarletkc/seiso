<script setup lang="ts">
import { computed, inject } from 'vue'
import { useData } from 'vitepress'
import { Icon } from '@iconify/vue'
import type { BannerConfig } from '../../types/theme-config'
import { themeContextKey } from '../../types/theme-context'
import viteMonoIcon from '@assets/icons/vite-mono.svg'
import vitestMonoIcon from '@assets/icons/vitest-mono.svg'
import rolldownMonoIcon from '@assets/icons/rolldown-mono.svg'
import oxcMonoIcon from '@assets/icons/oxc-mono.svg'
import viteplusMonoIcon from '@assets/icons/viteplus-mono.svg'

const { theme, frontmatter } = useData()

// Check if we're on a marketing page (non-doc layout) - matches Header.vue logic
const isMarketingPage = computed(() => {
  const layout = frontmatter.value.layout
  return layout === 'home' || (layout && layout !== 'doc' && layout !== 'page')
})

// Get banner configuration
const bannerConfig = computed<BannerConfig | undefined>(() => theme.value.banner)

// Only show if banner is configured
const showBanner = computed(() => {
  return bannerConfig.value?.text && bannerConfig.value?.url
})

const { footerBg: backgroundImage, monoIcon, logoAlt } = inject(themeContextKey)!

const bannerText = computed(() => bannerConfig.value?.text || '')
const bannerUrl = computed(() => bannerConfig.value?.url || '#')

type BannerIcon = NonNullable<BannerConfig['icon']>

const variantIcons: Record<BannerIcon, { alt: string; src: string }> = {
  vite: { alt: 'Vite', src: viteMonoIcon },
  vitest: { alt: 'Vitest', src: vitestMonoIcon },
  rolldown: { alt: 'Rolldown', src: rolldownMonoIcon },
  oxc: { alt: 'Oxc', src: oxcMonoIcon },
  viteplus: { alt: 'Vite+', src: viteplusMonoIcon }
}

const bannerIcon = computed(() => {
  const icon = bannerConfig.value?.icon
  return icon ? variantIcons[icon] : { alt: logoAlt, src: monoIcon }
})

// Determine link target
const linkTarget = computed(() => {
  if (bannerConfig.value?.target) {
    return bannerConfig.value.target
  }
  // Default: external URLs open in new tab
  const url = bannerConfig.value?.url || ''
  return url.startsWith('http') ? '_blank' : '_self'
})

// Rel attribute for security
const linkRel = computed(() => {
  return linkTarget.value === '_blank' ? 'noopener noreferrer' : undefined
})

function dismiss() {
  document.documentElement.classList.add('banner-dismissed')
  localStorage.setItem(`banner-dismissed-${bannerConfig.value?.id || ''}`, 'true')
}
</script>

<template>
  <div v-if="showBanner"
    :class="isMarketingPage
      ? 'top-banner hidden md:block relative w-full overflow-hidden'
      : 'top-banner hidden md:block relative w-full overflow-hidden lg:fixed lg:top-0 lg:left-0 lg:right-0 lg:z-60'"
    data-theme="dark">
    <a :href="bannerUrl" :target="linkTarget" :rel="linkRel"
      class="group block relative w-full no-underline text-white">
      <!-- Background image -->
      <img :src="backgroundImage" alt="" aria-hidden="true"
        class="absolute inset-0 w-full h-full object-cover object-bottom brightness-60"

        loading="eager" />

      <!-- Content overlay -->
      <div class="relative z-10 w-full h-10 flex px-4">
        <div class="flex items-center gap-2 w-full max-w-360 mx-auto px-4">
          <!-- Left: Variant icon -->
          <img :src="bannerIcon.src" :alt="`${bannerIcon.alt} icon`" class="w-5 h-5 -translate-y-px shrink-0 hidden sm:block drop-shadow-md/70" />

          <!-- Text -->
          <span
            class="text-xs translate-y-px font-medium font-mono leading-snug tracking-wide uppercase whitespace-nowrap overflow-hidden text-ellipsis text-shadow-md/50">
            {{ bannerText }}
          </span>

          <!-- Arrow icon -->
          <svg class="shrink-0 transition-transform duration-200 group-hover:translate-x-1" width="20" height="20"
            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect width="20" height="20" rx="4" fill="#08060D" />
            <rect x="0.5" y="0.5" width="19" height="19" rx="3.5" stroke="white" stroke-opacity="0.15" />
            <path d="M10 6L14 10L10 14" stroke="white" stroke-width="1.2" stroke-linejoin="round" />
            <path d="M14 10L6 10" stroke="white" stroke-width="1.2" stroke-linejoin="round" />
          </svg>
        </div>
      </div>
    </a>
    <!-- Close button -->
    <button @click="dismiss" aria-label="Close banner"
      class="absolute right-2 top-1/2 -translate-y-1/2 z-20 p-2 text-white hover:opacity-70 transition-opacity"
      type="button">
      <Icon icon="lucide:x" class="size-5 cursor-pointer" aria-hidden="true" />
    </button>
  </div>
</template>

<style>
:root.banner-dismissed .top-banner {
  display: none;
}

/* Set CSS variable for banner height - only on md+ where banner is visible */
@media (min-width: 768px) {
  .top-banner {
    --vp-banner-height: 40px;
  }

  :root:has(.top-banner):not(.banner-dismissed) {
    --vp-banner-height: 40px;
  }
}
</style>
