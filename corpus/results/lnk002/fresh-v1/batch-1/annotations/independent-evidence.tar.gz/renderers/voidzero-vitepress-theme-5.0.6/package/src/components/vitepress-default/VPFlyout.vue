<script lang="ts" setup generic="T extends DefaultTheme.NavItem">
import type { DefaultTheme } from 'vitepress/theme'
import type { IconOption } from '../../types/theme-config'
import { ref } from 'vue'
import { useFlyout } from '@vp-composables/flyout'
import { useIcon } from '@vp-composables/icon'
import { Icon } from '@iconify/vue'
import VPMenu from './VPMenu.vue'

const props = defineProps<{
  icon?: IconOption
  button?: string
  label?: string
  items?: T[]
}>()

const resolvedIcon = useIcon(() => props.icon)

const open = ref(false)
const el = ref<HTMLElement>()

useFlyout({ el, onBlur })

function onBlur() {
  open.value = false
}
</script>

<template>
  <div
    class="VPFlyout relative flex items-center"
    ref="el"
    @mouseenter="open = true"
    @mouseleave="open = false"
  >
    <button
      type="button"
      class="flex items-center px-3 py-2 text-base font-heading text-primary dark:text-white hover:opacity-70 transition-opacity whitespace-nowrap overflow-hidden text-ellipsis"
      aria-haspopup="true"
      :aria-expanded="open"
      :aria-label="label"
      @click="open = !open"
    >
      <span v-if="button || resolvedIcon" class="flex items-center gap-1 leading-normal overflow-hidden">
        <Icon v-if="resolvedIcon" :icon="resolvedIcon" class="shrink-0 mr-0.5" />
        <span v-if="button" v-html="button" class="overflow-hidden text-ellipsis"></span>
        <span class="vpi-chevron-down text-sm shrink-0" />
      </span>

      <span v-else class="vpi-more-horizontal text-xl" />
    </button>

    <div class="menu">
      <VPMenu :items>
        <slot />
      </VPMenu>
    </div>
  </div>
</template>

<style scoped>
/* Menu positioning and visibility states */
.menu {
  position: absolute;
  top: 100%;
  right: 0;
  display: none;
}

/* Add padding to create hover bridge without gap */
.menu::before {
  content: '';
  position: absolute;
  top: -8px;
  left: 0;
  right: 0;
  height: 8px;
}

button[aria-expanded="true"] + .menu,
.VPFlyout:hover .menu {
  display: block;
}

.VPFlyout.active button {
  color: var(--vp-c-brand-1);
}
</style>
