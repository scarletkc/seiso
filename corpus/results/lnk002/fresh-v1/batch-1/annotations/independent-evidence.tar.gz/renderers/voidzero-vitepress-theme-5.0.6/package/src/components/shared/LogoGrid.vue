<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'

interface Logo {
  src: string
  alt: string
}

interface Props {
  logos: Logo[]
}

const props = defineProps<Props>()

// Constants
const LOGO_WIDTH = 120
const LOGO_HEIGHT = 25
const GAP = 80

// Refs
const containerRef = ref<HTMLElement | null>(null)
const needsScrolling = ref(false)

// Calculate total content width
const contentWidth = computed(() => {
  const logoCount = props.logos.length
  return (logoCount * LOGO_WIDTH) + ((logoCount - 1) * GAP)
})

// Calculate animation duration based on number of logos
const animationDuration = computed(() => props.logos.length * 3) // 3 seconds per logo

// Check if content overflows container
const checkOverflow = () => {
  if (!containerRef.value) return

  const containerWidth = containerRef.value.offsetWidth
  needsScrolling.value = contentWidth.value > containerWidth
}

// Setup ResizeObserver
let resizeObserver: ResizeObserver | null = null

onMounted(() => {
  checkOverflow()

  if (containerRef.value) {
    resizeObserver = new ResizeObserver(() => {
      checkOverflow()
    })
    resizeObserver.observe(containerRef.value)
  }
})

onUnmounted(() => {
  if (resizeObserver) {
    resizeObserver.disconnect()
  }
})
</script>

<template>
  <div ref="containerRef" class="overflow-hidden py-6">
    <!-- Scrolling layout when content overflows -->
    <div v-if="needsScrolling" class="scroll-container">
      <div
        class="scroll-content"
        :style="{
          gap: `${GAP}px`,
          animationDuration: `${animationDuration}s`
        }"
      >
        <!-- Original set of logos -->
        <div class="flex items-center" :style="{ gap: `${GAP}px` }">
          <div
            v-for="logo in logos"
            :key="logo.alt"
            class="logo-container flex-shrink-0 relative flex items-center justify-center has-divider"
            :style="{
              width: `${LOGO_WIDTH}px`,
              height: `${LOGO_HEIGHT}px`,
            }"
          >
            <img
              loading="lazy"
              :src="logo.src"
              :alt="logo.alt"
              class="max-w-full max-h-full object-contain grayscale"
            >
          </div>
        </div>
        <!-- Duplicate set for seamless loop -->
        <div class="flex items-center" :style="{ gap: `${GAP}px` }">
          <div
            v-for="logo in logos"
            :key="`${logo.alt}-duplicate`"
            class="logo-container flex-shrink-0 relative flex items-center justify-center has-divider"
            :style="{
              width: `${LOGO_WIDTH}px`,
              height: `${LOGO_HEIGHT}px`,
            }"
          >
            <img
              loading="lazy"
              :src="logo.src"
              :alt="logo.alt"
              class="max-w-full max-h-full object-contain grayscale"
            >
          </div>
        </div>
      </div>
    </div>

    <!-- Static layout when content fits -->
    <div v-else class="flex items-center justify-evenly">
      <template v-for="(logo, index) in logos" :key="logo.alt">
        <div
          class="logo-container-static flex items-center justify-center"
          :style="{
            width: `${LOGO_WIDTH}px`,
            height: `${LOGO_HEIGHT}px`,
          }"
        >
          <img
            loading="lazy"
            :src="logo.src"
            :alt="logo.alt"
            class="max-w-full max-h-full object-contain grayscale"
          >
        </div>
        <!-- Divider between logos -->
        <div
          v-if="index < logos.length - 1"
          class="divider"
        ></div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.scroll-container {
  position: relative;
}

.scroll-content {
  display: flex;
  animation: scroll-horizontal linear infinite;
  width: fit-content;
}

.scroll-content > div {
  flex-shrink: 0;
}

.logo-container.has-divider::after {
  content: '';
  position: absolute;
  right: calc(v-bind(GAP) * -0.5px);
  top: -1.5rem;
  bottom: -1.5rem;
  width: 1px;
  background-color: var(--color-stroke);
}

/* Only apply dark styles when user prefers dark AND no data-theme override, OR when explicitly data-theme="dark" */
.dark:not([data-theme]) .logo-container.has-divider::after,
[data-theme="dark"] .logo-container.has-divider::after {
  background-color: var(--color-nickel);
}

.divider {
  width: 1px;
  align-self: stretch;
  background-color: var(--color-stroke);
  margin: -1.5rem 0;
}

.dark:not([data-theme]) .divider,
[data-theme="dark"] .divider {
  background-color: var(--color-nickel);
}

@keyframes scroll-horizontal {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(calc((v-bind(LOGO_WIDTH) * 1px + v-bind(GAP) * 1px) * v-bind('logos.length') * -1));
  }
}
</style>
