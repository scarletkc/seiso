<script setup lang="ts">
import { useData } from 'vitepress'

const props = defineProps<{
  background?: string
}>()

const { frontmatter } = useData()
</script>

<template>
  <div v-if="frontmatter.hero" class="wrapper wrapper--ticks grid lg:grid-cols-2 w-full border-nickel md:divide-x">
    <div class="flex flex-col p-15 sm:p-20 justify-between gap-20 items-center md:items-start">
      <div class="flex flex-col gap-5 items-center md:items-start text-center md:text-left">
        <a class="flex items-center gap-2" href="https://voidzero.dev" target="_blank">
          <span class="text-grey text-xs font-mono uppercase tracking-wide">By</span>
          <img src="@assets/logos/voidzero-light.svg" alt="VoidZero" class="h-2.5">
        </a>
        <h1 v-if="frontmatter.hero.text" class="text-white text-pretty max-w-[30rem]">
          {{ frontmatter.hero.text }}
        </h1>
        <p v-if="frontmatter.hero.tagline" class="text-white/70 md:text-lg max-w-[27rem] text-pretty">
          {{ frontmatter.hero.tagline }}
        </p>
        <div class="flex flex-col min-[410px]:flex-row items-center gap-5 mt-8">
          <a v-for="action in frontmatter.hero.actions" :key="action.text" :href="action.link"
            :target="action.link?.startsWith('http') ? '_blank' : ''" class="button inline-block w-fit"
            :class="{ 'button--primary': action.theme === 'brand' }">
            {{ action.text }}
          </a>
        </div>
      </div>
    </div>
    <div class="flex flex-col bg-cover bg-center" :style="props.background ? { backgroundImage: `url(${props.background})` } : undefined">
      <div class="relative px-10 pb-10 md:pt-10 h-full flex flex-col justify-center overflow-clip">
        <slot name="hero-image">
          <img v-if="frontmatter.hero.image?.src" :src="frontmatter.hero.image.src" :alt="frontmatter.hero.image.alt" class="max-h-[20rem]">
        </slot>
      </div>
    </div>
  </div>
</template>
