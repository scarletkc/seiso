<script lang="ts" setup>
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, ref } from 'vue'
import { useData } from '@vp-composables/data'
import { useLayout } from '@vp-composables/layout'
import VPLocalNavOutlineDropdown from './VPLocalNavOutlineDropdown.vue'

defineProps<{
  open: boolean
}>()

defineEmits<{
  (e: 'open-menu'): void
}>()

const { theme } = useData()
const { isHome, hasSidebar, headers, hasLocalNav } = useLayout()
const { y } = useWindowScroll()

const navHeight = ref(0)

onMounted(() => {
  navHeight.value = parseInt(
    getComputedStyle(document.documentElement).getPropertyValue(
      '--vp-nav-height'
    )
  )
})

const classes = computed(() => {
  return {
    VPLocalNav: true,
    'has-sidebar': hasSidebar.value,
    empty: !hasLocalNav.value,
    fixed: !hasLocalNav.value && !hasSidebar.value
  }
})
</script>

<template>
  <div
    v-if="!isHome && (hasLocalNav || hasSidebar || y >= navHeight)"
    :class="classes"
  >
    <div class="container">
      <button
        v-if="hasSidebar"
        class="menu"
        :aria-expanded="open"
        aria-controls="VPSidebarNav"
        @click="$emit('open-menu')"
      >
        <span class="vpi-align-left menu-icon"></span>
        <span class="menu-text">
          {{ theme.sidebarMenuLabel || 'Menu' }}
        </span>
      </button>

      <VPLocalNavOutlineDropdown :headers />
    </div>
  </div>
</template>

<style scoped>
.VPLocalNav {
  position: sticky;
  top: 0;
  /*rtl:ignore*/
  left: 0;
  z-index: var(--vp-z-index-local-nav);
  border-bottom: 1px solid var(--vp-c-gutter);
  padding-top: var(--vp-layout-top-height, 0px);
  width: 100%;
  background-color: var(--vp-local-nav-bg-color);
}

.dark .VPLocalNav {
  border-bottom-color: var(--color-nickel);
}

.VPLocalNav.fixed {
  position: fixed;
}

@media (min-width: 1024px) {
  .VPLocalNav {
    top: calc(var(--vp-nav-height) + var(--vp-banner-height, 0px) - 1px);
  }

  .VPLocalNav.has-sidebar {
    grid-column: 2;
    grid-row: 1;
    padding-left: 0;
    border-bottom: none;
  }

  .VPLocalNav.has-sidebar .container {
    border-bottom: 1px solid var(--vp-c-gutter);
  }

  .dark .VPLocalNav.has-sidebar .container {
    border-bottom-color: var(--color-nickel);
  }

  .VPLocalNav.empty {
    display: none;
  }
}

@media (min-width: 1280px) {
  .VPLocalNav {
    display: none;
  }
}

.container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 auto;
  max-width: 100%;
}

@media (min-width: 768px) {
  .container {
    max-width: calc(100vw - 2rem);
  }
}

@media (min-width: 90rem) {
  .container {
    max-width: 90rem;
  }
}

.menu {
  display: flex;
  align-items: center;
  line-height: 24px;
  font-size: 12px;
  font-weight: 500;
  color: var(--vp-c-text-2);
  transition: color 0.5s;
}

.menu:hover {
  color: var(--vp-c-text-1);
  transition: color 0.25s;
}

@media (min-width: 1024px) {
  .menu {
    display: none;
  }
}

.menu-icon {
  margin-right: 8px;
  font-size: 14px;
}

.menu,
:deep(.VPLocalNavOutlineDropdown > button) {
  padding: 12px 24px 11px;
}

@media (min-width: 768px) {
  .menu,
  :deep(.VPLocalNavOutlineDropdown > button) {
    padding: 12px 32px 11px;
  }
}
</style>
