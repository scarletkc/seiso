<script setup lang="ts">
import {ref, computed} from 'vue'

interface Props {
  endpoint?: string
  formId?: string
}

const props = defineProps<Props>()
const emit = defineEmits<{
  (e: 'success', email: string): void
  (e: 'error', error: Error): void
}>()

const email = ref('')
const formState = ref<'idle' | 'submitting' | 'success' | 'error'>('idle')
const errorMessage = ref('')

const isEnabled = computed(() => {
  return Boolean(props.endpoint && props.formId)
})

async function handleSubmit() {
  if (!email.value || formState.value === 'submitting' || !isEnabled.value) {
    return
  }

  formState.value = 'submitting'
  errorMessage.value = ''

  try {
    const response = await fetch(props.endpoint!, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: email.value,
        formId: props.formId,
      }),
    })

    if (!response.ok) {
      throw new Error('Subscription failed')
    }

    formState.value = 'success'
    emit('success', email.value)
    email.value = ''
  } catch (error: any) {
    console.error('Newsletter subscription error:', error)
    formState.value = 'error'
    errorMessage.value = error.message || 'An unknown error occurred'
    emit('error', error)
  } finally {
    setTimeout(() => {
      formState.value = 'idle'
    }, 2000)
  }
}
</script>

<template>
  <!-- Success State -->
  <div v-if="formState === 'success'" class="flex items-center gap-3 px-5 py-4 bg-white rounded border border-stroke">
    <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
    </svg>
    <span class="text-sm text-primary">Success! Please check your inbox.</span>
  </div>

  <!-- Error State -->
  <div v-else-if="formState === 'error'" class="flex items-center gap-3 px-5 py-4 bg-white rounded border border-red-300">
    <svg class="w-5 h-5 text-red-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
    </svg>
    <span class="text-sm text-red-600">{{ errorMessage || 'An error occurred. Please try again.' }}</span>
  </div>

  <!-- Form -->
  <form v-else @submit.prevent="handleSubmit">
    <div class="relative flex items-center bg-white rounded border border-stroke overflow-hidden">
      <input
        v-model="email"
        type="email"
        placeholder="Your email address"
        required
        :disabled="formState === 'submitting' || !isEnabled"
        class="flex-1 px-3 sm:px-5 py-3 sm:py-4 text-sm sm:text-base text-primary placeholder:text-grey bg-transparent outline-none disabled:opacity-50 disabled:cursor-not-allowed"
      />
      <button
        type="submit"
        :disabled="formState === 'submitting' || !isEnabled"
        class="flex-shrink-0 mr-1.5 sm:mr-2 px-3 sm:px-6 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
      >
        {{ formState === 'submitting' ? 'Subscribing...' : 'Subscribe' }}
      </button>
    </div>
  </form>
</template>
