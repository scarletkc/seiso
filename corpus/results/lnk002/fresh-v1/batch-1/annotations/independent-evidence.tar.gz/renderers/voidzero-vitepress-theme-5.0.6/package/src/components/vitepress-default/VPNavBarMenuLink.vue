<script lang="ts" setup>
import type { DefaultTheme } from 'vitepress/theme'
import { computed } from 'vue'
import { useData } from '@vp-composables/data'
import { useIcon } from '@vp-composables/icon'
import { isActive } from '../../support/vitepress-default/shared-utils'
import { Icon } from '@iconify/vue'
import VPLink from './VPLink.vue'

const props = defineProps<{
  item: DefaultTheme.NavItemWithLink
}>()

const { page } = useData()

const icon = useIcon(() => props.item.icon)

const href = computed(() =>
  typeof props.item.link === 'function'
    ? props.item.link(page.value)
    : props.item.link
)
</script>

<template>
  <VPLink
    class="flex items-center gap-1 px-3 py-2 text-base font-heading text-primary
     dark:text-white hover:opacity-85 transition-opacity whitespace-nowrap overflow-hidden text-ellipsis"
    :class="{
      active: isActive(
        page.relativePath,
        item.activeMatch || href,
        !!item.activeMatch
      )
    }" :href :target="item.target" :rel="item.rel" :no-icon="item.noIcon" tabindex="0">
    <Icon v-if="icon" :icon="icon" class="shrink-0 mr-0.5" />
    <span v-html="item.text"></span>
  </VPLink>
</template>

<style scoped>
.link.active {
  color: var(--vp-c-brand-1);
}

.link:hover {
  color: var(--vp-c-brand-1);
}
</style>
