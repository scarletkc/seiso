export function extendConfig<T>(c: T): T
