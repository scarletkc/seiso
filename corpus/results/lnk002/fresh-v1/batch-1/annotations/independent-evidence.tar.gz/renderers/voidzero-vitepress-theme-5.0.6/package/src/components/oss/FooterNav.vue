<script setup lang="ts">
import {computed} from 'vue'
import {useData} from 'vitepress'
import { Icon } from '@iconify/vue'

const {theme} = useData()

// Social icon name mapping
const socialIconName = (icon: string): string => {
  const key = icon.toLowerCase()
  if (key === 'twitter') return 'simple-icons:x'
  return `simple-icons:${key}`
}

// Footer configuration from theme
interface FooterLink {
  text: string
  link: string
}

interface FooterColumn {
  title: string
  items: FooterLink[]
}

interface SocialLink {
  icon: string
  link: string
  label?: string
}

interface FooterConfig {
  message?: string
  copyright?: string
  nav?: FooterColumn[]
  social?: SocialLink[]
}

const footerConfig = computed<FooterConfig>(() => {
  const footer = theme.value.footer || {}
  return footer as FooterConfig
})
const footerNav = computed(() => footerConfig.value.nav || [])
const footerSocial = computed(() => footerConfig.value.social || [])
const footerCopyright = computed(() =>
  footerConfig.value.copyright || `© ${new Date().getFullYear()} VoidZero Inc. All Rights Reserved.`
)

// Get display label for social link
const getSocialLabel = (social: SocialLink): string => {
  if (social.label) return social.label
  const labels: Record<string, string> = {
    github: 'GitHub',
    discord: 'Discord',
    bluesky: 'Bluesky',
    twitter: 'X.com',
    x: 'X.com',
  }
  return labels[social.icon.toLowerCase()] || social.icon
}
</script>

<template>
  <div>
    <section class="wrapper wrapper--ticks border-t">
      <div
          class="px-5 md:px-24 pt-10 md:pt-16 pb-16 md:pb-40 flex flex-col md:flex-row gap-10 md:gap-0 md:justify-between">
        <div class="flex flex-col md:flex-row gap-10 md:gap-20">
          <div v-for="column in footerNav" :key="column.title">
            <p class="text-[var(--vp-c-text-2)] text-xs font-mono uppercase tracking-wide mb-8">{{ column.title }}</p>
            <ul class="flex flex-col gap-3">
              <li v-for="item in column.items" :key="item.link">
                <a :href="item.link" class="text-[var(--vp-c-text-1)] text-base">{{ item.text }}</a>
              </li>
            </ul>
          </div>
        </div>
        <div v-if="footerSocial.length">
          <p class="text-[var(--vp-c-text-2)] text-xs font-mono uppercase tracking-wide mb-8">Social</p>
          <ul class="flex flex-col gap-3">
            <li v-for="social in footerSocial" :key="social.link">
              <a :href="social.link" class="text-[var(--vp-c-text-1)] text-base flex gap-3 items-center" target="_blank"
                 rel="noopener noreferrer">
                <Icon :icon="socialIconName(social.icon)" class="size-[18px]" :aria-label="getSocialLabel(social)" />
                {{ getSocialLabel(social) }}
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>
    <section
        class="wrapper wrapper--ticks border-t py-5 px-5 md:px-24 flex flex-col md:flex-row gap-3 md:gap-0 justify-between items-start md:items-center">
      <p class="text-sm">{{ footerCopyright }}</p>
      <div class="gap-10 text-sm hidden md:flex">
        <!--        <a href="https://voidzero.dev/terms" class="text-grey">Terms & Conditions</a>
                <a href="https://voidzero.dev/privacy" class="text-grey">Privacy Policy</a>-->
      </div>
    </section>
  </div>
</template>
