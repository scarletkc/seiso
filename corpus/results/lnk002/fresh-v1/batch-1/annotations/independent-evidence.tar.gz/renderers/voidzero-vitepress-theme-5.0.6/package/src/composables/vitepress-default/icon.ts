import { computed, type MaybeRefOrGetter, toValue } from 'vue'
import { useData } from './data'
import type { IconOption } from '../../types/theme-config'

export function useIcon(icon: MaybeRefOrGetter<IconOption | undefined>) {
  const { isDark } = useData()
  return computed(() => {
    const val = toValue(icon)
    if (!val) return undefined
    if (typeof val === 'string') return val
    return isDark.value ? val.dark : val.light
  })
}
