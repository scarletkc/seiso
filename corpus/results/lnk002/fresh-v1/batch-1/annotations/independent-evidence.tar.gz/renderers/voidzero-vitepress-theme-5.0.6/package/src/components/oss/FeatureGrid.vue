<script setup>
import { Icon } from '@iconify/vue'
import { useData } from 'vitepress'

const { frontmatter } = useData()
</script>

<template>
  <section v-if="frontmatter.features"
    class="wrapper wrapper--ticks border-t grid md:grid-cols-2 divide-x divide-y divide-nickel">
    <div v-for="feature in frontmatter.features" :key="feature.icon || feature.iconify"
      class="flex flex-col gap-3 justify-between border-r-0 md:odd:border-r md:nth-last-2:border-b-0">
      <div class="px-10 py-8 sm:px-15 sm:py-12 flex flex-col gap-3">
        <p class="text-2xl">
          <Icon v-if="feature.iconify" :icon="feature.iconify" width="1em" height="1em" />
          <template v-else>{{ feature.icon }}</template>
        </p>
        <h5 class="text-balance sm:text-pretty text-white">
          {{ feature.title }}
        </h5>
        <p class="sm:max-w-md text-base">
          {{ feature.details }}
        </p>
      </div>
    </div>
  </section>
</template>
