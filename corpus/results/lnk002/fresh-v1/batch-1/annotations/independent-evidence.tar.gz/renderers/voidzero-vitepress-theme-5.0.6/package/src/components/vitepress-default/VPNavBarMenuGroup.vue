<script lang="ts" setup>
import type { DefaultTheme } from 'vitepress/theme'
import { computed } from 'vue'
import { useData } from '@vp-composables/data'
import { isActive } from '../../support/vitepress-default/shared-utils'
import VPFlyout from './VPFlyout.vue'

const props = defineProps<{
  item: DefaultTheme.NavItemWithChildren
}>()

const { page } = useData()

const isChildActive = (navItem: DefaultTheme.NavItem) => {
  if ('component' in navItem) return false

  if ('link' in navItem) {
    return isActive(
      page.value.relativePath,
      typeof navItem.link === "function" ? navItem.link(page.value) : navItem.link,
      !!props.item.activeMatch
    )
  }

  return navItem.items.some(isChildActive)
}

const childrenActive = computed(() => isChildActive(props.item))
</script>

<template>
  <VPFlyout
    :class="{
      VPNavBarMenuGroup: true,
      active:
        isActive(page.relativePath, item.activeMatch, !!item.activeMatch) ||
        childrenActive
    }"
    :icon="item.icon"
    :button="item.text"
    :items="item.items"
  />
</template>
