import { VoidZeroTheme, themeContextKey } from "./";
import type { Theme } from "vitepress";

// inject project variant assets
import logoDark from "@assets/logos/rolldown-dark.svg";
import logoLight from "@assets/logos/rolldown-light.svg";
import footerBg from "@assets/rolldown/footer-background.jpg";
import monoIcon from "@assets/icons/rolldown-mono.svg";

export default {
  ...VoidZeroTheme,
  enhanceApp(ctx) {
    ctx.app.provide(themeContextKey, {
      logoDark,
      logoLight,
      logoAlt: "Rolldown",
      footerBg,
      monoIcon,
    });
    VoidZeroTheme.enhanceApp(ctx)
  },
} satisfies Theme;
