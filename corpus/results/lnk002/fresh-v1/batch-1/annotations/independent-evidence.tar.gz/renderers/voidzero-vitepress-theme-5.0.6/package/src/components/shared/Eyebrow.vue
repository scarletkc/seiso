<script setup lang="ts">
withDefaults(defineProps<{
  title: string
  ticks?: boolean
}>(), {
  ticks: true
})
</script>

<template>
  <section class="wrapper border-t p-5 md:pl-10" :class="{ 'wrapper--ticks': ticks }">
    <span class="text-nickel dark:text-white text-xs font-medium font-mono uppercase tracking-wide">{{ title }}</span>
  </section>
</template>