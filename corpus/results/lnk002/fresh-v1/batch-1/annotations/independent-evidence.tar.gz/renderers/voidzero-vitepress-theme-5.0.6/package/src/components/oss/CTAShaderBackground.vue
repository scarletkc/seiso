<script setup lang="ts">
import { computed } from 'vue'
import {
  Shader,
  Circle,
  DiffuseBlur,
  Godrays,
  RadialGradient,
  Ripples,
} from 'shaders/vue'

type Variant = 'vite' | 'vitest' | 'rolldown' | 'oxc' | 'viteplus'

interface ColorPalette {
  dark: string
  mid: string
  light: string
  circle: string
}

const palettes: Record<Variant, ColorPalette> = {
  vite: {
    dark: '#2E066B',
    mid: '#6A15DB',
    light: '#cdb5ea',
    circle: '#743DA9',
  },
  vitest: {
    dark: '#013D16',
    mid: '#00c65b',
    light: '#33ffb1',
    circle: '#6CDD60',
  },
  rolldown: {
    dark: '#502901',
    mid: '#bf3f00',
    light: '#ff5602',
    circle: '#e4a458',
  },
  oxc: {
    dark: '#004347',
    mid: '#009f9f',
    light: '#1BFBDE',
    circle: '#45d3ba',
  },
}

const props = withDefaults(defineProps<{
  variant?: Variant
}>(), {
  variant: 'vite'
})

const colors = computed(() => palettes[props.variant] || palettes.vite)
const transparent = '#00000000'
</script>

<template>
  <Shader class="hidden md:block absolute inset-0 -z-0">
    <RadialGradient
        :color-a="colors.mid"
        :color-b="colors.dark"
        :center="{'x':0.5,'y':2}"
        :radius="1.09"
        color-space="oklab"
        />
    <Ripples
        :center="{'x':0.5,'y':2}"
        :color-a="colors.mid"
        :color-b="transparent"
        :speed="0.4"
        :frequency="6.4"
        :softness="0.8"
        :thickness="0.7"
        :visible="true"
        />
    <Ripples
        :center="{'x':0.5,'y':2}"
        :color-a="colors.light"
        :color-b="transparent"
        :speed="0.4"
        :frequency="6.4"
        :softness="0.35"
        :thickness="0.02"
        :phase="5.76"
        :opacity="0.5"
        :visible="true"
        />
    <Ripples
        :center="{'x':0.5,'y':2}"
        :color-a="colors.mid"
        :color-b="transparent"
        :speed="0.4"
        :frequency="6.4"
        :softness="0.7"
        :thickness="0.02"
        blend-mode="linearDodge"
        :visible="true"
        />
    <Circle
        :color="colors.circle"
        :softness="0.7"
        :center="{'x':0.5,'y':1.1}"
        />
    <DiffuseBlur
        :intensity="80"
        :visible="true"
        />
    <Godrays
        :center="{'x':0.5,'y':2}"
        :density="10"
        :intensity="0.6"
        :spotty="0"
        :speed="0.8"
        :ray-color="colors.light"
        :background-color="transparent"
        blend-mode="colorDodge"
        :opacity="0.2"
        :visible="true"/>
  </Shader>
</template>