<script setup lang="ts">

</script>

<template>
  <section class="wrapper wrapper--ticks border-t h-16 sm:h-30">
  </section>
</template>

<style scoped>

</style>