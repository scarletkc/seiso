/**
 * Search configuration utilities
 * Provides runtime-only provider detection and Algolia config validation.
 */

import type { DefaultTheme } from 'vitepress/theme'

export interface AlgoliaConfigValidation {
  isValid: boolean
  missingFields: string[]
  config: DefaultTheme.AlgoliaSearchOptions | null
}

/**
 * Validates Algolia search configuration.
 * Returns detailed validation result including which fields are missing.
 */
export function validateAlgoliaConfig(
  config: DefaultTheme.AlgoliaSearchOptions | undefined
): AlgoliaConfigValidation {
  if (!config) {
    return {
      isValid: false,
      missingFields: ['appId', 'apiKey', 'indexName'],
      config: null
    }
  }

  const missingFields: string[] = []

  if (!config.appId) missingFields.push('appId')
  if (!config.apiKey) missingFields.push('apiKey')
  if (!config.indexName) missingFields.push('indexName')

  return {
    isValid: missingFields.length === 0,
    missingFields,
    config: missingFields.length === 0 ? config : null
  }
}

/**
 * Determines the effective search provider from runtime config.
 *
 * NOTE: This uses runtime-only detection. We intentionally DO NOT fall back
 * to compile-time constants (__VP_LOCAL_SEARCH__, __ALGOLIA__) because:
 * 1. This theme is pre-built - those constants are evaluated at theme build time
 * 2. They don't reflect the downstream project's actual configuration
 * 3. This caused crashes when __ALGOLIA__ was true but no config was provided
 */
export function getSearchProvider(
  themeConfig: DefaultTheme.Config | undefined
): 'local' | 'algolia' | 'none' {
  const provider = themeConfig?.search?.provider

  if (provider === 'local') return 'local'
  if (provider === 'algolia') return 'algolia'

  // Legacy support: check for top-level algolia config (VitePress 1.x style)
  if ((themeConfig as any)?.algolia) return 'algolia'

  return 'none'
}
