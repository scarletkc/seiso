<script setup lang="ts">
import * as rive from "@rive-app/canvas-lite"
import riveWasm from "@rive-app/canvas-lite/rive.wasm?url"
import { ref, onMounted, onUnmounted, computed } from "vue"

rive.RuntimeLoader.setWasmUrl(riveWasm)

interface Props {
  desktopSrc: string
  mobileSrc?: string
  breakpoint?: number
  stateMachines?: string
  canvasClass?: string
  desktopWidth?: number
  desktopHeight?: number
  mobileWidth?: number
  mobileHeight?: number
  enableHover?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  breakpoint: 768, // md breakpoint
  stateMachines: "State Machine 1",
  canvasClass: "w-full",
  enableHover: false
})

const canvasRef = ref<HTMLCanvasElement | null>(null)
const containerRef = ref<HTMLElement | null>(null)
let riveInstance: rive.Rive | null = null
let hasStarted = ref(false)
let observer: IntersectionObserver | null = null
const hasHoverAnimation = ref(false)
const hoverTriggered = ref(false)

const isMobile = ref(false)

const checkMobile = () => {
  isMobile.value = window.innerWidth < props.breakpoint
}

const getCurrentSrc = () => {
  return isMobile.value && props.mobileSrc ? props.mobileSrc : props.desktopSrc
}

const currentWidth = computed(() => {
  return isMobile.value && props.mobileWidth ? props.mobileWidth : props.desktopWidth
})

const currentHeight = computed(() => {
  return isMobile.value && props.mobileHeight ? props.mobileHeight : props.desktopHeight
})

const loadAnimation = () => {
  if (!canvasRef.value || riveInstance) return

  const src = getCurrentSrc()

  const config: any = {
    src,
    canvas: canvasRef.value,
    autoplay: false,
    onLoad: () => {
      riveInstance?.resizeDrawingSurfaceToCanvas()

      // Check if hover animation exists
      const animationNames = riveInstance?.animationNames || []
      hasHoverAnimation.value = animationNames.includes('hover')
    }
  }

  // If hover is enabled AND on desktop, use hover animation
  // Otherwise use state machines for more complex interactions
  if (props.enableHover && !isMobile.value) {
    config.animations = 'hover'
  } else {
    config.stateMachines = props.stateMachines
  }

  riveInstance = new rive.Rive(config)
}

const playAnimation = () => {
  if (riveInstance) {
    riveInstance.play()
  }
}

const handleMouseEnter = () => {
  // Only enable hover on desktop
  if (props.enableHover && !isMobile.value && hasHoverAnimation.value && riveInstance && !hoverTriggered.value) {
    hoverTriggered.value = true
    riveInstance.play('hover')
  }
}

const handleMouseLeave = () => {
  // Do nothing - let the animation play out
}

const cleanupAnimation = () => {
  if (riveInstance) {
    riveInstance.cleanup()
    riveInstance = null
  }
}

const handleResize = () => {
  const wasMobile = isMobile.value
  checkMobile()

  // If mobile state changed, reload with correct source
  if (wasMobile !== isMobile.value) {
    const wasPlaying = hasStarted.value
    cleanupAnimation()
    loadAnimation()
    if (wasPlaying) {
      playAnimation()
    }
  }
}

onMounted(() => {
  checkMobile()

  // Load animation immediately
  loadAnimation()

  // Only set up intersection observer if hover is not enabled OR on mobile
  if (!props.enableHover || isMobile.value) {
    observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting && !hasStarted.value) {
              hasStarted.value = true
              playAnimation()
            }
          })
        },
        {
          threshold: 0.1 // Start when 10% visible
        }
    )

    if (containerRef.value) {
      observer.observe(containerRef.value)
    }
  }

  // Listen for window resize to handle breakpoint changes
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  cleanupAnimation()

  if (observer && containerRef.value) {
    observer.unobserve(containerRef.value)
    observer.disconnect()
  }

  window.removeEventListener('resize', handleResize)
})
</script>

<template>
  <div
    ref="containerRef"
    :class="['touch-none select-none', { 'pointer-events-none': isMobile }]"
    @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave"
  >
    <canvas
        ref="canvasRef"
        :width="currentWidth"
        :height="currentHeight"
        :class="canvasClass"
    />
  </div>
</template>

<style scoped>
</style>
