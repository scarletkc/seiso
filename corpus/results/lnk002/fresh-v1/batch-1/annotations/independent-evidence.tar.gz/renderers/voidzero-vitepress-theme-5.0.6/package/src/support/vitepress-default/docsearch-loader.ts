/**
 * Conditional DocSearch CSS/JS loader
 * Only loads @docsearch packages when Algolia search is actually used.
 * This allows projects using local search to avoid installing docsearch dependencies.
 */

let cssLoaded = false
let cssLoadPromise: Promise<boolean> | null = null

/**
 * Loads @docsearch/css dynamically.
 * Returns true if loaded successfully, false if package is not available.
 * Caches result to avoid multiple load attempts.
 */
export async function loadDocSearchCSS(): Promise<boolean> {
  if (cssLoaded) return true

  // Prevent multiple concurrent load attempts
  if (cssLoadPromise) return cssLoadPromise

  cssLoadPromise = (async () => {
    try {
      await import('@docsearch/css')
      cssLoaded = true
      return true
    } catch (e) {
      console.warn(
        '[VitePress Theme] @docsearch/css not found. ' +
        'If using Algolia search, install: npm install @docsearch/css @docsearch/js'
      )
      return false
    }
  })()

  return cssLoadPromise
}

/**
 * Loads @docsearch/js dynamically and returns the docsearch function.
 * Returns null if the package is not available.
 */
export async function loadDocSearchJS(): Promise<((props: any) => void) | null> {
  try {
    const module = await import('@docsearch/js')
    return module.default
  } catch (e) {
    console.error(
      '[VitePress Theme] @docsearch/js not found. ' +
      'Install: npm install @docsearch/css @docsearch/js'
    )
    return null
  }
}
