<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { useData, useRoute } from 'vitepress'
import { normalizeLink } from '@vp-support/utils'
import { ref, computed, onMounted, onUnmounted, watch, nextTick, inject } from 'vue'
import { getSearchProvider } from '@vp-support/search-config'
import { themeContextKey } from '../../types/theme-context'
import { EXTERNAL_URL_RE } from '../../support/vitepress-default/shared-utils'

// Import VitePress header components
import VPNavBarSearch from '@vp-default/VPNavBarSearch.vue'
import VPNavBarMenu from '@vp-default/VPNavBarMenu.vue'
import VPNavBarAppearance from '@vp-default/VPNavBarAppearance.vue'
import VPNavBarTranslations from '@vp-default/VPNavBarTranslations.vue'
import VPNavBarSocialLinks from '@vp-default/VPNavBarSocialLinks.vue'
import VPNavBarExtra from '@vp-default/VPNavBarExtra.vue'
import VPSwitchAppearance from '@vp-default/VPSwitchAppearance.vue'
import VPSocialLinks from '@vp-default/VPSocialLinks.vue'

import { useLangs } from '@vp-composables/langs'

const { theme, frontmatter, isDark } = useData()
const nav = theme.value.nav

const route = useRoute()

// Language/locale support
const { localeLinks, currentLang } = useLangs({ correspondingLink: true })

// Hide appearance toggle when theme is forced via frontmatter
const isForcedTheme = computed(() => !!frontmatter.value.theme)

const { logoDark, logoLight, logoAlt } = inject(themeContextKey)!

// Check if we're on a marketing page (non-doc layout)
const isMarketingPage = computed(() => {
  const layout = frontmatter.value.layout
  return layout === 'home' || (layout && layout !== 'doc' && layout !== 'page')
})

// Check if search is available (for hiding mobile search buttons when not configured)
const isSearchAvailable = computed(() => {
  const provider = getSearchProvider(theme.value)
  // Show mobile search buttons if any search provider is configured
  return provider === 'local' || provider === 'algolia'
})

// Mobile menu state
const mobileMenuOpen = ref(false)
const expandedAccordions = ref<Set<number>>(new Set())
const languageMenuOpen = ref(false)

// Check if nav item is a dropdown (has children)
const isDropdown = (item: any) => 'items' in item && Array.isArray(item.items)

// Check if a link is external
const isExternalLink = (link: string) => EXTERNAL_URL_RE.test(link)

// Toggle accordion for dropdown items
const toggleAccordion = (index: number) => {
  if (expandedAccordions.value.has(index)) {
    expandedAccordions.value.delete(index)
  } else {
    expandedAccordions.value.add(index)
  }
  // Trigger reactivity
  expandedAccordions.value = new Set(expandedAccordions.value)
}

// Handle keyboard navigation
const handleKeydown = (e: KeyboardEvent) => {
  if (e.key === 'Escape' && mobileMenuOpen.value) {
    closeMobileMenu()
  }
}

// Body scroll lock for mobile menu
const lockBodyScroll = () => {
  const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth
  document.body.style.overflow = 'hidden'
  document.body.style.position = 'fixed'
  document.body.style.width = '100%'
  document.body.style.top = '0'
  if (scrollbarWidth > 0) {
    document.body.style.paddingRight = `${scrollbarWidth}px`
  }
}

const unlockBodyScroll = () => {
  document.body.style.overflow = ''
  document.body.style.position = ''
  document.body.style.width = ''
  document.body.style.top = ''
  document.body.style.paddingRight = ''
}

// Toggle mobile menu
const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value
  if (mobileMenuOpen.value) {
    lockBodyScroll()
  } else {
    unlockBodyScroll()
  }
}

// Close mobile menu
const closeMobileMenu = () => {
  mobileMenuOpen.value = false
  expandedAccordions.value = new Set()
  languageMenuOpen.value = false
  unlockBodyScroll()
}

// Trigger search by dispatching keyboard event
const triggerSearch = () => {
  const event = new KeyboardEvent('keydown', {
    key: 'k',
    code: 'KeyK',
    metaKey: true,
    ctrlKey: true,
    bubbles: true
  })
  window.dispatchEvent(event)
}

// Focus trap for mobile menu
const focusTrap = {
  firstFocusableEl: null as HTMLElement | null,
  lastFocusableEl: null as HTMLElement | null,

  activate: () => {
    const mobileMenu = document.getElementById('mobile-menu')
    if (!mobileMenu) return

    const focusableElements = mobileMenu.querySelectorAll(
      'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )

    if (focusableElements.length === 0) return

    focusTrap.firstFocusableEl = focusableElements[0] as HTMLElement
    focusTrap.lastFocusableEl = focusableElements[focusableElements.length - 1] as HTMLElement

    focusTrap.firstFocusableEl?.focus()

    document.addEventListener('keydown', focusTrap.handleTabKey)
  },

  deactivate: () => {
    document.removeEventListener('keydown', focusTrap.handleTabKey)
    focusTrap.firstFocusableEl = null
    focusTrap.lastFocusableEl = null
  },

  handleTabKey: (e: KeyboardEvent) => {
    if (e.key !== 'Tab') return

    if (e.shiftKey) {
      if (document.activeElement === focusTrap.firstFocusableEl) {
        focusTrap.lastFocusableEl?.focus()
        e.preventDefault()
      }
    } else {
      if (document.activeElement === focusTrap.lastFocusableEl) {
        focusTrap.firstFocusableEl?.focus()
        e.preventDefault()
      }
    }
  }
}

// Activate/deactivate focus trap when mobile menu opens/closes
watch(mobileMenuOpen, (isOpen) => {
  if (isOpen) {
    nextTick(() => {
      focusTrap.activate()
    })
  } else {
    focusTrap.deactivate()
  }
})

onMounted(() => {
  document.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeydown)
  unlockBodyScroll()
})
</script>

<template>
  <div
    :data-theme="isDark ? 'dark' : undefined"
    :class="isMarketingPage ? 'relative w-full z-50' : 'relative w-full z-50 lg:fixed lg:left-0 lg:right-0 lg:top-[var(--vp-banner-height,0)]'">
    <header
      class="wrapper px-6 py-5 flex items-center justify-between relative bg-white dark:bg-primary border-b border-stroke dark:border-nickel">
      <!-- Left side: Logo + Nav -->
      <div class="flex gap-10 self-stretch">
        <a href="/" class="flex flex-col items-start justify-center -mx-2 px-2">
          <slot name="nav-bar-title-before" />
          <img class="h-4 block dark:hidden" :src="logoDark" :alt="logoAlt" />
          <img class="h-4 hidden dark:block" :src="logoLight" :alt="logoAlt" />
          <slot name="nav-bar-title-after" />
        </a>

        <!-- Desktop navigation -->
        <div class="hidden lg:flex items-center gap-4">
          <VPNavBarMenu />
        </div>
      </div>

      <!-- Right side: Search + Dark/Light + Language + Social + Hamburger -->
      <div class="flex items-center gap-2 lg:gap-4">
        <!-- Search - single instance shared between tablet and desktop -->
        <div class="hidden lg:flex items-center">
          <VPNavBarSearch />
        </div>

        <!-- Tablet: Extra (three dots dropdown) - visible 1024px-1280px -->
        <div class="hidden lg:flex xl:hidden items-center gap-4">
          <VPNavBarExtra />
        </div>

        <!-- Desktop utilities - visible 1280px+ -->
        <div class="hidden xl:flex items-center gap-4">
          <VPNavBarAppearance v-if="!isForcedTheme" />
          <VPNavBarTranslations />
          <VPNavBarSocialLinks />
        </div>

        <!-- Mobile search icon - visible <1024px, hidden if search unavailable -->
        <button v-if="isSearchAvailable" @click="triggerSearch" aria-label="Search"
          class="lg:hidden p-2 text-primary dark:text-white hover:opacity-70 transition-opacity cursor-pointer"
          type="button">
          <Icon icon="lucide:search" class="size-5" />
        </button>

        <!-- Mobile hamburger - visible <1024px -->
        <button @click="toggleMobileMenu" :aria-expanded="mobileMenuOpen" aria-controls="mobile-menu"
          aria-label="Toggle navigation menu"
          class="lg:hidden p-2 -mr-2 text-primary dark:text-white hover:opacity-70 transition-opacity cursor-pointer"
          type="button">
          <svg v-if="!mobileMenuOpen" class="size-6 block dark:hidden" viewBox="0 0 18 8"
            xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0.75H18" stroke="#08060D" stroke-width="1.5" />
            <path d="M0 6.75H18" stroke="#08060D" stroke-width="1.5" />
          </svg>
          <svg v-if="!mobileMenuOpen" class="size-6 hidden dark:block" viewBox="0 0 18 8"
            xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0.75H18" stroke="#FFFFFF" stroke-width="1.5" />
            <path d="M0 6.75H18" stroke="#FFFFFF" stroke-width="1.5" />
          </svg>

        </button>
      </div>
    </header>

    <!-- Decorative ticks at bottom corners -->
    <div class="wrapper relative h-0 tick-left tick-right"></div>

    <!-- Mobile Menu Overlay - Full Screen -->
    <div v-if="mobileMenuOpen" id="mobile-menu" role="dialog" aria-modal="true" aria-label="Mobile navigation menu"
      :data-theme="isForcedTheme ? 'dark' : undefined"
      class="lg:hidden fixed inset-0 z-[1001] bg-white dark:bg-primary">
      <section class="wrapper animate-fade-in">

        <!-- Internal Header with Logo, Search and Close Button -->
        <div class="w-full pl-5 pr-5 py-5 lg:py-7 flex items-center justify-between">
          <a href="/">
            <img class="h-4 block dark:hidden" :src="logoDark" :alt="logoAlt" />
            <img class="h-4 hidden dark:block" :src="logoLight" :alt="logoAlt" />
          </a>
          <div class="flex items-center gap-2">
            <!-- Search button - hidden if search unavailable -->
            <button v-if="isSearchAvailable" @click="triggerSearch" aria-label="Search"
              class="p-2 text-primary dark:text-white hover:opacity-70 transition-opacity cursor-pointer" type="button">
              <Icon icon="lucide:search" class="size-5" />
            </button>
            <!-- Close button -->
            <button @click="closeMobileMenu" aria-label="Close navigation menu"
              class="p-2 -mr-2 text-primary dark:text-white hover:opacity-70 transition-opacity" type="button">
              <Icon icon="lucide:x" class="size-6 cursor-pointer" aria-hidden="true" />
            </button>
          </div>
        </div>

        <!-- Scrollable content container -->
        <div
          class="overflow-y-auto flex flex-col [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
          style="height: calc(100vh - 88px);">
          <!-- Navigation Items - Top Section -->
          <nav class="flex-1 w-full pt-6 pb-8">
            <ul class="space-y-1">
              <li v-for="(navItem, index) in nav" :key="navItem.text">
                <!-- Dropdown item - render as accordion -->
                <template v-if="isDropdown(navItem)">
                  <button @click="toggleAccordion(index)"
                    class="w-full flex items-center justify-between py-3 px-4 text-base font-sans text-primary dark:text-white"
                    :aria-expanded="expandedAccordions.has(index)">
                    <span>{{ navItem.text }}</span>
                    <Icon icon="lucide:chevron-down" class="size-4 transition-transform duration-200"
                      :class="{ 'rotate-180': expandedAccordions.has(index) }" />
                  </button>
                  <!-- Accordion content -->
                  <ul v-show="expandedAccordions.has(index)" class="pl-4 space-y-1">
                    <template v-for="childItem in navItem.items" :key="childItem.link || childItem.text">
                      <!-- Direct link item -->
                      <li v-if="'link' in childItem">
                        <a :href="normalizeLink(childItem.link)" @click="closeMobileMenu"
                          :target="isExternalLink(childItem.link) ? '_blank' : undefined"
                          :rel="isExternalLink(childItem.link) ? 'noreferrer' : undefined"
                          :class="[
                            { 'bg-primary/10 dark:bg-white/10': route.path === normalizeLink(childItem.link) },
                            { 'vp-external-link-icon': isExternalLink(childItem.link) }
                          ]"
                          class="block py-1.5 px-4 text-sm font-sans text-grey dark:text-white/80 hover:text-primary dark:hover:text-white">
                          {{ childItem.text }}
                        </a>
                      </li>
                      <!-- Nested group/section (items with dividers) -->
                      <li v-else-if="'items' in childItem">
                        <p v-if="childItem.text"
                          class="pt-3 pb-1 px-4 text-xs font-semibold uppercase tracking-wider text-grey/70 dark:text-white/50">
                          {{ childItem.text }}
                        </p>
                        <ul class="pl-4 space-y-1">
                          <li v-for="nestedItem in childItem.items" :key="nestedItem.link || nestedItem.text">
                            <a v-if="nestedItem.link" :href="normalizeLink(nestedItem.link)" @click="closeMobileMenu"
                              :target="isExternalLink(nestedItem.link) ? '_blank' : undefined"
                              :rel="isExternalLink(nestedItem.link) ? 'noreferrer' : undefined"
                              :class="[
                                { 'bg-primary/10 dark:bg-white/10': route.path === normalizeLink(nestedItem.link) },
                                { 'vp-external-link-icon': isExternalLink(nestedItem.link) }
                              ]"
                              class="block py-1.5 px-4 text-sm font-sans text-grey dark:text-white/80 hover:text-primary dark:hover:text-white">
                              {{ nestedItem.text }}
                            </a>
                          </li>
                        </ul>
                      </li>
                    </template>
                  </ul>
                </template>
                <!-- Regular link item -->
                <a v-else-if="navItem.link" :href="normalizeLink(navItem.link)" @click="closeMobileMenu"
                  :target="isExternalLink(navItem.link) ? '_blank' : undefined"
                  :rel="isExternalLink(navItem.link) ? 'noreferrer' : undefined"
                  :class="[
                    { 'bg-primary/10 dark:bg-white/10': route.path === normalizeLink(navItem.link) },
                    { 'vp-external-link-icon': isExternalLink(navItem.link) }
                  ]"
                  class="block py-3 px-4 text-base font-sans text-primary dark:text-white">
                  {{ navItem.text }}
                </a>
                <!-- Nav item without link (shouldn't happen, but defensive) -->
                <span v-else class="block py-3 px-4 text-base font-sans text-primary dark:text-white">
                  {{ navItem.text }}
                </span>
              </li>
            </ul>
          </nav>

          <!-- Bottom Section - Language + Appearance + Social -->
          <div
            class="w-full pt-6 pb-12 border-t border-stroke dark:border-nickel relative tick-left tick-right mt-auto">
            <div class="space-y-6">
              <!-- Language Selector (Accordion) -->
              <div v-if="localeLinks.length && currentLang.label" class="px-4">
                <button @click="languageMenuOpen = !languageMenuOpen"
                  class="w-full flex items-center justify-between text-grey dark:text-white/80 text-sm font-medium"
                  :aria-expanded="languageMenuOpen">
                  <span>{{ theme.langMenuLabel || 'Language' }}</span>
                  <Icon icon="lucide:chevron-down" class="size-4 transition-transform duration-200"
                    :class="{ 'rotate-180': languageMenuOpen }" />
                </button>
                <ul v-show="languageMenuOpen" class="mt-3 space-y-1">
                  <li v-for="locale in localeLinks" :key="locale.link">
                    <a :href="locale.link" @click="closeMobileMenu"
                      class="block py-2 text-sm text-primary dark:text-white hover:opacity-70 transition-opacity">
                      {{ locale.text }}
                    </a>
                  </li>
                </ul>
              </div>

              <!-- Appearance Toggle (hidden on homepage) -->
              <div v-if="!isForcedTheme" class="flex items-center justify-between px-4">
                <span class="text-grey dark:text-white/80 text-sm font-medium">Appearance</span>
                <VPSwitchAppearance />
              </div>

              <!-- Social Icons -->
              <div class="flex items-center justify-center gap-4 pt-4">
                  <VPSocialLinks
                    @click="closeMobileMenu"
                    v-if="theme.socialLinks"
                    :links="theme.socialLinks"
                  />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

.animate-fade-in {
  animation: fadeIn 300ms ease-out 100ms forwards;
  opacity: 0;
}
</style>
