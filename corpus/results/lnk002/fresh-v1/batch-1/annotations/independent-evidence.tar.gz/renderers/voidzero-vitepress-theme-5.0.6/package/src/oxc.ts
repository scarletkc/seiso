import { VoidZeroTheme, themeContextKey } from "./";
import type { Theme } from "vitepress";

// inject project variant assets
import logoDark from "@assets/logos/oxc-dark.svg";
import logoLight from "@assets/logos/oxc-light.svg";
import footerBg from "@assets/oxc/footer-background.jpg";
import monoIcon from "@assets/icons/oxc-mono.svg";

export default {
  ...VoidZeroTheme,
  enhanceApp(ctx) {
    ctx.app.provide(themeContextKey, {
      logoDark,
      logoLight,
      logoAlt: "Oxc",
      footerBg,
      monoIcon,
    });
    VoidZeroTheme.enhanceApp(ctx)
  },
} satisfies Theme;
