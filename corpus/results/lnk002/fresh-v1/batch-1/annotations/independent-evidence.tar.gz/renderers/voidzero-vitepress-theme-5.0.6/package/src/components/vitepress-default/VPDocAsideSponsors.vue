<script setup lang="ts">
import type { GridSize } from '@vp-composables/sponsor-grid'
import type { Sponsors } from './VPSponsors.vue'
import type { Sponsor } from './VPSponsorsGrid.vue'
import VPSponsors from './VPSponsors.vue'

defineProps<{
  tier?: string
  size?: GridSize
  data: Sponsors[] | Sponsor[]
}>()
</script>

<template>
  <div class="VPDocAsideSponsors">
    <VPSponsors mode="aside" :tier :size :data />
  </div>
</template>
