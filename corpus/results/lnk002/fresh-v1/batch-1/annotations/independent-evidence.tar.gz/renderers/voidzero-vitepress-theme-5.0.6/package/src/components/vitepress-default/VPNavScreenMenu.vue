<script lang="ts" setup>
import { useData } from '@vp-composables/data'
import VPNavScreenMenuLink from './VPNavScreenMenuLink.vue'
import VPNavScreenMenuGroup from './VPNavScreenMenuGroup.vue'

const { theme } = useData()
</script>

<template>
  <nav v-if="theme.nav" class="VPNavScreenMenu">
    <template v-for="item in theme.nav" :key="JSON.stringify(item)">
      <VPNavScreenMenuLink v-if="'link' in item" :item />
      <component
        v-else-if="'component' in item"
        :is="item.component"
        v-bind="item.props"
        screen-menu
      />
      <VPNavScreenMenuGroup
        v-else
        :text="item.text || ''"
        :icon="item.icon"
        :items="item.items"
      />
    </template>
  </nav>
</template>
