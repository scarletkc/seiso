<script setup lang="ts">
import { computed } from 'vue'
import type { SponsorTier, SponsorSize } from '../../types/sponsors'

interface Props {
  sponsors?: SponsorTier[]
  heading?: string
  description?: string
  sponsorLink?: string
  sponsorLinkText?: string
  sideBySideTiers?: [string, string] // e.g., ['bronze', 'backers'] for side-by-side layout
  logoStyle?: 'opencollective'
}

const props = withDefaults(defineProps<Props>(), {
  heading: 'Free & open source',
  description: 'Vite is MIT Licensed and will always be free and open source. This is made possible by our contributors and these companies:',
  sponsorLink: 'https://github.com/sponsors/vitejs',
  sponsorLinkText: 'Become a Sponsor',
})

const sizeConfig: Record<SponsorSize, { columns: number; padding: string; logoSize: string; avatarMode?: boolean }> = {
  big: { columns: 3, padding: 'py-16', logoSize: 'h-13 w-[220px]' },
  medium: { columns: 5, padding: 'py-7', logoSize: 'h-8 w-[120px]' },
  small: { columns: 7, padding: 'py-5', logoSize: 'h-6 w-[100px]' },
  avatar: { columns: 15, padding: 'py-3', logoSize: 'w-10 h-10', avatarMode: true },
}

const gridClasses: Record<number, string> = {
  1: 'grid-cols-1',
  2: 'grid-cols-1 sm:grid-cols-2',
  3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
  4: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4',
  5: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5',
  6: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6',
  7: 'grid-cols-2 sm:grid-cols-4 lg:grid-cols-7',
}

const getEffectiveColumns = (size: SponsorSize, itemCount: number) =>
  Math.min(sizeConfig[size].columns, itemCount)

const getGridColumns = (size: SponsorSize, itemCount: number) =>
  gridClasses[getEffectiveColumns(size, itemCount)] || 'grid-cols-1'

const getEmptyCells = (itemCount: number, size: SponsorSize) => {
  const cols = getEffectiveColumns(size, itemCount)
  const remainder = itemCount % cols
  return remainder === 0 ? 0 : cols - remainder
}

// Calculate empty slots for backers grid (maintain visual consistency)
const getBackerEmptySlots = (itemCount: number, minSlots: number = 30) => {
  const targetSlots = Math.max(itemCount, minSlots)
  return Math.max(0, targetSlots - itemCount)
}

// Side-by-side tier data (for layouts like OXC: Bronze + Backers)
const sideBySideData = computed(() => {
  if (!props.sponsors || !props.sideBySideTiers) return null

  const [leftTierName, rightTierName] = props.sideBySideTiers
  const leftTier = props.sponsors.find(t => t.tier.toLowerCase() === leftTierName.toLowerCase())
  const rightTier = props.sponsors.find(t => t.tier.toLowerCase() === rightTierName.toLowerCase())

  if (!leftTier || !rightTier) return null

  return { left: leftTier, right: rightTier }
})

// Standard stacked tier data (excludes side-by-side tiers)
const stackedSponsors = computed(() => {
  if (!props.sponsors) return []
  if (!props.sideBySideTiers) return props.sponsors

  const sideBySideNames = props.sideBySideTiers.map(n => n.toLowerCase())
  return props.sponsors.filter(tier => !sideBySideNames.includes(tier.tier.toLowerCase()))
})
</script>

<template>
  <div class="wrapper wrapper--ticks border-t py-14 sm:py-30 px-10">
    <div
      class="flex flex-col md:flex-row justify-between items-center gap-8 md:gap-20 text-center md:text-left md:pl-15">
      <div class="flex flex-col gap-3">
        <h3 class="text-white max-w-xl text-balance">{{ heading }}</h3>
        <p class="max-w-lg text-white/70 text-balance">{{ description }}</p>
        <a :href="sponsorLink" target="_blank" class="button w-fit mt-8 mx-auto md:mx-0">{{ sponsorLinkText }}</a>
      </div>
      <a class="flex gap-8 md:gap-12 items-start justify-center md:justify-start md:pr-25" href="https://voidzero.dev"
        target="_blank">
        <img src="../../assets/vite/vite-by-voidzero.png" alt="Brought to you by VoidZero"
          class="h-44 max-w-full object-contain mt-10 md:mt-0" />
      </a>
    </div>
  </div>
  <div v-if="sponsors && sponsors.length > 0" class="wrapper"
    :class="{ 'spsr-style-oc': logoStyle === 'opencollective' }">
    <!-- Standard Stacked Sponsors Grid -->
    <div v-for="(tier, tierIndex) in stackedSponsors" :key="tierIndex" class="border-t border-nickel">
      <!-- Tier Heading -->
      <div class="py-5 px-5 sm:px-10 border-b border-nickel">
        <span class="text-white/70 text-xs font-mono uppercase tracking-wide">
          {{ tier.tier }}
        </span>
      </div>

      <!-- Avatar Mode Grid (for backers-style tiers) -->
      <div v-if="sizeConfig[tier.size].avatarMode" class="backers-grid px-5 sm:px-10 py-6">
        <a v-for="(sponsor, index) in tier.items" :key="index" :href="sponsor.url" target="_blank"
          rel="noopener noreferrer" class="backer-avatar group relative">
          <img :src="sponsor.img" :alt="sponsor.name"
            class="w-10 h-10 rounded object-cover border border-nickel transition-all group-hover:border-white/50 group-hover:scale-110" />
          <span class="backer-tooltip">{{ sponsor.name }}</span>
        </a>
        <!-- Empty placeholder slots -->
        <div v-for="emptyIndex in getBackerEmptySlots(tier.items.length)" :key="`empty-${emptyIndex}`"
          class="backer-avatar-placeholder" aria-hidden="true">
          <div class="w-10 h-10 rounded border border-nickel/30"></div>
        </div>
      </div>

      <!-- Standard Logo Grid -->
      <div v-else class="grid *:border-r *:border-b *:border-nickel"
        :class="getGridColumns(tier.size, tier.items.length)">
        <a v-for="(sponsor, index) in tier.items" :key="index" :href="sponsor.url" target="_blank"
          rel="noopener noreferrer"
          class="spsr-link flex items-center justify-center px-8 transition-opacity opacity-85 hover:opacity-100"
          :class="sizeConfig[tier.size].padding">
          <img :src="sponsor.img" :alt="sponsor.name" class="spsr-logo object-contain"
            :class="sizeConfig[tier.size].logoSize" />
          <span class="spsr-name ml-5">{{ sponsor.name }}</span>
        </a>

        <!-- Empty cells to fill incomplete rows -->
        <div v-for="emptyIndex in getEmptyCells(tier.items.length, tier.size)" :key="`empty-${emptyIndex}`"
          class="spsr-link flex items-center justify-center px-8" :class="sizeConfig[tier.size].padding"
          aria-hidden="true" />
      </div>
    </div>

    <!-- Side-by-Side Layout (e.g., Bronze + Backers) -->
    <div v-if="sideBySideData" class="grid grid-cols-1 lg:grid-cols-2 border-t border-nickel">
      <!-- Left Tier -->
      <div class="border-b lg:border-b-0 lg:border-r border-nickel">
        <div class="py-5 px-5 sm:px-10 border-b border-nickel">
          <span class="text-white/70 text-xs font-mono uppercase tracking-wide">
            {{ sideBySideData.left.tier }}
          </span>
        </div>
        <div class="flex flex-col">
          <a v-for="(sponsor, index) in sideBySideData.left.items" :key="index" :href="sponsor.url" target="_blank"
            rel="noopener noreferrer"
            class="spsr-link flex items-center justify-center px-8 py-12 transition-opacity opacity-85 hover:opacity-100 border-b border-nickel last:border-b-0">
            <img :src="sponsor.img" :alt="sponsor.name" class="spsr-logo object-contain"
              :class="sizeConfig[sideBySideData.left.size].logoSize" />
            <span class="spsr-name ml-5">{{ sponsor.name }}</span>
          </a>
        </div>
      </div>

      <!-- Right Tier (Backers style) -->
      <div>
        <div class="py-5 px-5 sm:px-10 border-b border-nickel">
          <span class="text-white/70 text-xs font-mono uppercase tracking-wide">
            {{ sideBySideData.right.tier }}
          </span>
        </div>
        <div v-if="sizeConfig[sideBySideData.right.size].avatarMode" class="backers-grid px-5 sm:px-10 py-6">
          <a v-for="(sponsor, index) in sideBySideData.right.items" :key="index" :href="sponsor.url" target="_blank"
            rel="noopener noreferrer" class="backer-avatar group relative">
            <img :src="sponsor.img" :alt="sponsor.name"
              class="w-10 h-10 rounded object-cover border border-nickel transition-all group-hover:border-white/50 group-hover:scale-110" />
            <span class="backer-tooltip">{{ sponsor.name }}</span>
          </a>
          <!-- Empty placeholder slots for visual consistency -->
          <div v-for="emptyIndex in getBackerEmptySlots(sideBySideData.right.items.length)" :key="`empty-${emptyIndex}`"
            class="backer-avatar-placeholder" aria-hidden="true">
            <div class="w-10 h-10 rounded border border-nickel/30"></div>
          </div>
        </div>
        <!-- Fallback to standard grid if not avatar mode -->
        <div v-else class="grid *:border-r *:border-b *:border-nickel"
          :class="getGridColumns(sideBySideData.right.size, sideBySideData.right.items.length)">
          <a v-for="(sponsor, index) in sideBySideData.right.items" :key="index" :href="sponsor.url" target="_blank"
            rel="noopener noreferrer"
            class="spsr-link flex items-center justify-center px-8 transition-opacity opacity-85 hover:opacity-100"
            :class="sizeConfig[sideBySideData.right.size].padding">
            <img :src="sponsor.img" :alt="sponsor.name" class="spsr-logo object-contain"
              :class="sizeConfig[sideBySideData.right.size].logoSize" />
              <span class="spsr-name ml-5">{{ sponsor.name }}</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* Sponsor grid - clip outer borders using overflow */
.grid[class*="grid-cols"] {
  overflow: hidden;
  margin-right: -1px;
  margin-bottom: -1px;
}

.spsr-logo {
  filter: grayscale(1) invert(1);
}

.spsr-style-oc .spsr-logo {
  filter: none;
  width: auto;
  border-radius: 0.25rem;
}

.spsr-name {
  display: none;
}

.spsr-style-oc .spsr-name {
  display: inline-block;
}

/* Backers dense avatar grid */
.backers-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  justify-content: center;
}

@media (min-width: 768px) {
  .backers-grid {
    justify-content: flex-start;
  }
}

.backer-avatar {
  position: relative;
  display: inline-flex;
  cursor: pointer;
}

.backer-avatar img {
  transition: transform 0.2s ease, border-color 0.2s ease;
}

/* Tooltip styling */
.backer-tooltip {
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
  padding: 0.25rem 0.5rem;
  background: rgba(0, 0, 0, 0.9);
  color: white;
  font-size: 0.75rem;
  white-space: nowrap;
  border-radius: 0.25rem;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s ease;
  margin-bottom: 0.25rem;
  z-index: 10;
}

.backer-avatar:hover .backer-tooltip {
  opacity: 1;
}

/* Empty placeholder slots */
.backer-avatar-placeholder {
  opacity: 0.3;
}

.backer-avatar-placeholder div {
  background: transparent;
}
</style>
