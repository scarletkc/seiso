<script setup lang="ts">
import {ProgressIndicator, ProgressRoot} from 'reka-ui'
interface Props {
  data: any
  backgroundImage?: string
  large?: boolean
}
const {data, backgroundImage, large} = defineProps<Props>()
</script>

<template>
  <div class="flex items-center w-full gap-3">
    <p :class="[
      'font-mono text-xs uppercase tracking-wide w-24 md:w-36 shrink-0',
      data.isPrimary ? 'text-white' : 'text-grey'
    ]">{{ data.name }}</p>
    <ProgressRoot
        :class="[
          'rounded-xs relative overflow-hidden bg-slate w-full',
          large ? 'h-6' : 'h-3'
        ]"
    >
      <ProgressIndicator
          :class="[
            'indicator rounded-xs block relative h-full bg-center bg-cover transition-transform overflow-hidden duration-[660ms] ease-[cubic-bezier(0.65, 0, 0.35, 1)]',
            data.isPrimary ? 'bg-wine' : 'bg-grey'
          ]"
          :style="{
            width: `${data.percentage}%`,
            backgroundImage: data.isPrimary && backgroundImage ? `url(${backgroundImage})` : undefined
          }"
      />
    </ProgressRoot>
    <p :class="[
      'font-mono text-xs uppercase tracking-wide shrink-0',
      data.isPrimary ? 'text-white' : 'text-grey'
    ]">/ {{ data.time }}</p>
  </div>
</template>