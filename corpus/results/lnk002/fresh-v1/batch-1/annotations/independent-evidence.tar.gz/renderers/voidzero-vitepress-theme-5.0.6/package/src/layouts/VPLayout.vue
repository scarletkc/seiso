<script setup lang="ts">
import { computed, useSlots } from 'vue'
import { useData } from 'vitepress'

// Import VitePress default layout
import VPDefaultLayout from '@vp-default/Layout.vue'

// Import custom variant layouts/components
import OSSHeader from '@components/oss/Header.vue'
import TopBanner from '@components/oss/TopBanner.vue'

const { frontmatter, site } = useData()
const slots = useSlots()

// Determine variant from theme config
const variant = computed(() => site.value.themeConfig?.variant || 'vite')

// Determine which layout to use based on frontmatter.layout
// Default behavior (no layout specified) = use VitePress doc layout
// This matches standard VitePress behavior
const useVPLayout = computed(() => {
  const layout = frontmatter.value.layout

  // If no layout specified, default to VitePress doc layout (standard behavior)
  if (!layout) return true

  // Explicit VitePress layouts
  if (layout === 'doc' || layout === 'page') return true

  // For 'home' or any other custom layout, use custom theme
  return false
})
</script>

<template>
  <!-- Documentation layout - add .docs-layout class for scoped typography -->
  <div v-if="useVPLayout" class="docs-layout" :data-theme="frontmatter.theme" :data-variant="variant">
    <VPDefaultLayout>
      <!-- Forward all slots to the default layout -->
      <template v-for="(_, name) in slots" #[name]="slotData">
        <slot :name="name" v-bind="slotData || {}" />
      </template>
    </VPDefaultLayout>
  </div>
  <div v-else class="marketing-layout" :data-theme="frontmatter.theme" :data-variant="variant">
    <TopBanner />
    <slot name="layout-top" />
    <OSSHeader>
      <template #nav-bar-title-before><slot name="nav-bar-title-before" /></template>
      <template #nav-bar-title-after><slot name="nav-bar-title-after" /></template>
    </OSSHeader>
    <Content />
    <slot name="layout-bottom" />
  </div>
</template>

<style scoped>
/* Layout container styles */
.docs-layout,
.marketing-layout {
  min-height: 100vh;
}

.viteplus-layout,
.voidzero-layout {
  display: flex;
  flex-direction: column;
}
</style>
