/**
 * @voidzerodev/vitepress-theme
 *
 * Full fork of VitePress default theme with custom variant system.
 * Supports both traditional VitePress doc layouts and custom variant layouts.
 * Set themeConfig.variant to 'voidzero' or 'viteplus' in your VitePress config.
 *
 * Layouts:
 * - layout: 'doc' | 'home' | 'page' → Uses VitePress default layout
 * - No layout or custom → Uses variant-specific custom layout
 */

// NOTE: @docsearch/css is loaded dynamically in VPAlgoliaSearchBox.vue
// This allows local search users to avoid installing docsearch packages

// Unified design system - single import
// Contains: tokens → base → docs → marketing (in that order)
import type { Theme } from "vitepress";
import { watch } from "vue";

// Main layout router
import VPLayout from "./layouts/VPLayout.vue";
// VitePress default theme components (forked)
import VPBadge from "@vp-default/VPBadge.vue";

const VoidZeroTheme = {
  Layout: VPLayout, // Smart layout router that switches between VP and custom layouts
  enhanceApp({ app, router, siteData }) {
    const variant = siteData.value.themeConfig?.variant || "voidzero";
    if (typeof document !== "undefined") {
      document.documentElement.setAttribute("data-variant", variant);

      // Watch for frontmatter.theme changes and apply theme logic
      watch(
        () => router.route.data.frontmatter?.theme,
        (theme) => {
          if (theme) {
            // Forced theme via frontmatter
            document.documentElement.setAttribute("data-theme", theme);
          } else {
            // OSS: Respect user preference, but default to dark if no preference
            document.documentElement.removeAttribute("data-theme");

            const hasUserPreference = localStorage.getItem(
              "vitepress-theme-appearance"
            );
            if (
              !hasUserPreference &&
              !document.documentElement.classList.contains("dark")
            ) {
              // No user preference - set dark as default for OSS
              document.documentElement.classList.add("dark");
            }
          }
        },
        { immediate: true }
      );
    }

    // VitePress default theme component (for markdown usage)
    app.component("Badge", VPBadge);
  },
} satisfies Theme;

// VP components (for use in Markdown and custom components)
export { default as VPBadge } from "@vp-default/VPBadge.vue";
export { default as VPButton } from "@vp-default/VPButton.vue";
export { default as VPDocAsideSponsors } from "@vp-default/VPDocAsideSponsors.vue";
export { default as VPFeatures } from "@vp-default/VPFeatures.vue";
export { default as VPHomeContent } from "@vp-default/VPHomeContent.vue";
export { default as VPHomeFeatures } from "@vp-default/VPHomeFeatures.vue";
export { default as VPHomeHero } from "@vp-default/VPHomeHero.vue";
export { default as VPHomeSponsors } from "@vp-default/VPHomeSponsors.vue";
export { default as VPImage } from "@vp-default/VPImage.vue";
export { default as VPLink } from "@vp-default/VPLink.vue";
export { default as VPSocialLink } from "@vp-default/VPSocialLink.vue";
export { default as VPSocialLinks } from "@vp-default/VPSocialLinks.vue";
export { default as VPSponsors } from "@vp-default/VPSponsors.vue";
export { default as VPTeamMembers } from "@vp-default/VPTeamMembers.vue";
export { default as VPTeamPage } from "@vp-default/VPTeamPage.vue";
export { default as VPTeamPageSection } from "@vp-default/VPTeamPageSection.vue";
export { default as VPTeamPageTitle } from "@vp-default/VPTeamPageTitle.vue";

// Export custom layouts and components
export { default as FooterNav } from "@components/oss/FooterNav.vue";
export { VoidZeroTheme };
export default VoidZeroTheme;

// Export types
export type { Sponsors } from "./components/vitepress-default/VPSponsors.vue";
export type {
  BannerConfig,
  FooterConfig,
  FooterColumn,
  FooterLink,
  FooterSocialLink,
  GridSize,
  IconOption,
  Sponsor,
  SponsorTier,
  VoidZeroThemeConfig,
} from "./types/theme-config";
export { type ThemeContext, themeContextKey } from "./types/theme-context";
