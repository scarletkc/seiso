<script lang="ts" setup>
import { useScrollLock } from '@vueuse/core'
import { inBrowser } from 'vitepress'
import { ref, watch } from 'vue'
import { useLayout } from '@vp-composables/layout'
import VPSidebarGroup from './VPSidebarGroup.vue'

const { sidebarGroups, hasSidebar } = useLayout()

const props = defineProps<{
  open: boolean
}>()

// a11y: focus Nav element when menu has opened
const navEl = ref<HTMLElement | null>(null)
const isLocked = useScrollLock(inBrowser ? document.body : null)

watch(
  [props, navEl],
  () => {
    if (props.open) {
      isLocked.value = true
      navEl.value?.focus()
    } else isLocked.value = false
  },
  { immediate: true, flush: 'post' }
)

const key = ref(0)

watch(
  sidebarGroups,
  () => {
    key.value += 1
  },
  { deep: true }
)
</script>

<template>
  <aside
    v-if="hasSidebar"
    class="VPSidebar"
    :class="{ open }"
    ref="navEl"
    @click.stop
  >
    <nav
      class="nav"
      id="VPSidebarNav"
      aria-labelledby="sidebar-aria-label"
      tabindex="-1"
    >
      <span class="visually-hidden" id="sidebar-aria-label">
        Sidebar Navigation
      </span>

      <slot name="sidebar-nav-before" />
      <VPSidebarGroup :items="sidebarGroups" :key />
      <slot name="sidebar-nav-after" />
    </nav>
  </aside>
</template>

<style scoped>
.VPSidebar {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  z-index: var(--vp-z-index-sidebar);
  padding: 20px 32px 96px;
  width: calc(100vw - 64px);
  max-width: 320px;
  background-color: var(--vp-c-bg);
  opacity: 0;
  box-shadow: var(--vp-c-shadow-3);
  overflow-x: hidden;
  overflow-y: auto;
  transform: translateX(calc(-100% - 1rem));
  transition: opacity 0.5s, transform 0.25s ease;
  overscroll-behavior: contain;
}

.VPSidebar.open {
  opacity: 1;
  visibility: visible;
  transform: translateX(0);
  transition: opacity 0.25s,
    transform 0.5s cubic-bezier(0.19, 1, 0.22, 1);
}

@media (min-width: 1024px) {
  .VPSidebar {
    position: sticky;
    top: calc(var(--vp-nav-height) + var(--vp-banner-height, 0px) - 1px);
    bottom: unset;
    left: unset;
    padding-left: 32px;
    width: var(--vp-sidebar-width);
    max-width: 100%;
    height: calc(100vh - var(--vp-nav-height) - var(--vp-banner-height, 0px) + 1px);
    background-color: transparent;
    opacity: 1;
    visibility: visible;
    box-shadow: none;
    transform: translateX(0);
    z-index: auto;
    grid-column: 1;
    grid-row: 2;
    align-self: start;
  }
}

.nav {
  outline: 0;
}

/* Sidebar border */
.VPSidebar {
  border-right: 1px solid var(--vp-c-divider);
}
</style>
