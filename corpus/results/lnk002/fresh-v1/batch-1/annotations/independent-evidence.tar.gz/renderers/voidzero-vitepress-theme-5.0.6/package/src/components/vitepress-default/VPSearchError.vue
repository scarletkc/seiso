<script lang="ts" setup>
/**
 * Fallback component for async component errors.
 * Renders nothing - search silently fails without crashing the header.
 */
</script>

<template>
  <!-- Intentionally empty - search fails silently -->
</template>
