<script setup lang="ts">
import {inject} from 'vue'
import { themeContextKey } from '../../types/theme-context'
import FooterNav from './FooterNav.vue'

// Props for CTA section
withDefaults(defineProps<{
  heading?: string
  subheading?: string
  buttonText?: string
  buttonLink?: string
}>(), {
  heading: 'Get Started',
  subheading: 'Prepare for a development environment that can finally keep pace with the speed of your mind.',
  buttonText: 'Get Started',
  buttonLink: '/guide/'
})

const { footerBg: backgroundImage } = inject(themeContextKey)!
</script>

<template>
  <footer class="bg-primary" data-theme="dark">
    <section class="wrapper">
      <div class="relative w-full">
        <img :src="backgroundImage" alt="Footer background" inert loading="lazy"
             class="absolute inset-0 w-full h-full object-cover z-0"/>
        <div
            class="relative z-10 w-full sm:w-2xl flex flex-col justify-start items-center gap-5 px-5 sm:px-0 py-10 md:py-30 mx-auto">
          <h2 class="text-center text-white text-balance drop-shadow-sm/70">{{ heading }}</h2>
          <p class="text-white max-w-md text-balance text-center drop-shadow-sm/70">{{ subheading }}</p>
          <a :href="buttonLink"
             class="button button--white mt-5">
            {{ buttonText }}
          </a>
        </div>
      </div>
    </section>
    <FooterNav />
  </footer>
</template>
