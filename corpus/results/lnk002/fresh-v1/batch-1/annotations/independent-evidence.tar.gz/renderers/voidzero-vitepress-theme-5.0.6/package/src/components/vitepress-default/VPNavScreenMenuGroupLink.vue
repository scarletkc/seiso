<script lang="ts" setup>
import type { DefaultTheme } from 'vitepress/theme'
import { computed, inject } from 'vue'
import { useData } from '@vp-composables/data'
import { useIcon } from '@vp-composables/icon'
import { navInjectionKey } from '@vp-composables/nav'
import { Icon } from '@iconify/vue'
import VPLink from './VPLink.vue'

const props = defineProps<{
  item: DefaultTheme.NavItemWithLink
}>()

const { page } = useData()

const icon = useIcon(() => props.item.icon)

const href = computed(() =>
  typeof props.item.link === 'function'
    ? props.item.link(page.value)
    : props.item.link
)

const { closeScreen } = inject(navInjectionKey)!
</script>

<template>
  <VPLink
    class="VPNavScreenMenuGroupLink"
    :href
    :target="item.target"
    :rel="item.rel"
    :no-icon="item.noIcon"
    @click="closeScreen"
  >
    <Icon v-if="icon" :icon="icon" class="shrink-0 mr-0.5" />
    <span v-html="item.text"></span>
  </VPLink>
</template>

<style scoped>
.VPNavScreenMenuGroupLink {
  display: flex;
  align-items: center;
  margin-left: 12px;
  line-height: 32px;
  font-size: 14px;
  font-weight: 400;
  color: var(--vp-c-text-1);
  transition: color 0.25s;
}

.VPNavScreenMenuGroupLink:hover {
  color: var(--vp-c-brand-1);
}
</style>
