<script setup lang="ts">
import {useData, useRoute} from 'vitepress'

const {site, theme} = useData()
const nav = theme.value.nav

const route = useRoute()
</script>

<template>
  <header class="wrapper px-6 py-7 flex items-center justify-between">
    <div class="flex items-center gap-10">
      <a href="/">
        <img class="h-4" src="@assets/viteplus/logo.svg" alt="Vite+"/>
      </a>
      <ul class="nav">
        <li v-for="navItem in nav" :key="navItem.link">
          <a
              :class="{ active: route.path === navItem.link }"
              :href="navItem.link"
          >
            {{ navItem.text }}
          </a>
        </li>
      </ul>
    </div>

    <div class="flex items-center gap-6">
      <slot name="right-side">
        <!-- Right-aligned links / calls-to-action -->
      </slot>
    </div>
  </header>
</template>

<style scoped>

</style>
