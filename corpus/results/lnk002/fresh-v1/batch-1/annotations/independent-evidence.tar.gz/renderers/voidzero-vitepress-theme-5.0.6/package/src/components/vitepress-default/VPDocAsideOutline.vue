<script setup lang="ts">
import { ref } from 'vue'
import { useData } from '@vp-composables/data'
import { resolveTitle, useActiveAnchor } from '@vp-composables/outline'
import VPDocOutlineItem from './VPDocOutlineItem.vue'
import { useLayout } from '@vp-composables/layout'

const { theme } = useData()

const container = ref()
const marker = ref()

const { headers, hasLocalNav } = useLayout()

useActiveAnchor(container, marker)
</script>

<template>
  <nav
    aria-labelledby="doc-outline-aria-label"
    class="VPDocAsideOutline"
    :class="{ 'has-outline': hasLocalNav }"
    ref="container"
  >
    <div class="content">
      <div class="outline-marker" ref="marker" />

      <div
        aria-level="2"
        class="outline-title flex items-center gap-2 uppercase text-xs text-grey tracking-wide font-medium"
        id="doc-outline-aria-label"
        role="heading"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M7.3335 3.66669H14.0002" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
          <path d="M3.6 11.2618C4.31111 11.738 4.66667 11.9762 4.66667 12.3334C4.66667 12.6906 4.31111 12.9287 3.6 13.405C2.88889 13.8812 2.53333 14.1193 2.26667 13.9408C2 13.7622 2 13.2859 2 12.3334C2 11.3808 2 10.9046 2.26667 10.726C2.53333 10.5474 2.88889 10.7855 3.6 11.2618Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
          <path d="M3.6 2.59509C4.31111 3.07135 4.66667 3.30947 4.66667 3.66667C4.66667 4.02386 4.31111 4.26199 3.6 4.73825C2.88889 5.21451 2.53333 5.45263 2.26667 5.27403C2 5.09544 2 4.61918 2 3.66667C2 2.71415 2 2.23789 2.26667 2.0593C2.53333 1.8807 2.88889 2.11883 3.6 2.59509Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
          <path d="M7.3335 8H14.0002" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
          <path d="M7.3335 12.3333H14.0002" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
        </svg>
        {{ resolveTitle(theme) }}
      </div>

      <VPDocOutlineItem :headers :root="true" />
    </div>
  </nav>
</template>

<style scoped>
.VPDocAsideOutline {
  display: none;
}

.VPDocAsideOutline.has-outline {
  display: block;
}

.content {
  position: relative;
  font-size: 13px;
  font-weight: 500;
}

.outline-marker {
  position: absolute;
  top: 32px;
  left: -33px;
  z-index: 0;
  opacity: 0;
  width: 2px;
  border-radius: 2px;
  height: 18px;
  background-color: var(--vp-c-text-1);
  transition:
    top 0.25s cubic-bezier(0, 1, 0.5, 1),
    background-color 0.5s,
    opacity 0.25s;
}

.outline-title {
  line-height: 32px;
}
</style>
