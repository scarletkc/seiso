<script lang="ts" setup>
/**
 * Forked from VitePress default theme to:
 * 1. Avoid CSS side effects (removed @docsearch/css import)
 * 2. Use runtime-only provider detection (no compile-time constants)
 * 3. Add error boundaries to prevent crashes
 * 4. Validate Algolia config before rendering
 */
import { onKeyStroke } from '@vueuse/core'
import type { DefaultTheme } from 'vitepress/theme'
import { computed, defineAsyncComponent, onMounted, ref } from 'vue'
import { useData } from '@vp-composables/data'
import { resolveMode, resolveOptionsForLanguage } from '@vp-support/docsearch'
import { smartComputed } from '@vp-support/reactivity'
import VPNavBarAskAiButton from './VPNavBarAskAiButton.vue'
import VPNavBarSearchButton from './VPNavBarSearchButton.vue'
import VPSearchError from './VPSearchError.vue'
import { getSearchProvider, validateAlgoliaConfig } from '@vp-support/search-config'

const { theme, localeIndex, lang } = useData()

// Runtime-only provider detection
// NOTE: We intentionally do NOT fall back to compile-time constants (__VP_LOCAL_SEARCH__, __ALGOLIA__)
// because this theme is pre-built and those constants reflect theme build time, not downstream config.
const provider = computed(() => getSearchProvider(theme.value))

const isLocal = computed(() => provider.value === 'local')

const algoliaOptions = smartComputed<DefaultTheme.AlgoliaSearchOptions>(() => {
  return resolveOptionsForLanguage(
    theme.value.search?.options || {},
    localeIndex.value,
    lang.value
  )
})

// Validate Algolia config before attempting to render
const algoliaValidation = computed(() => {
  if (provider.value !== 'algolia') return null
  const options = algoliaOptions.value
  return validateAlgoliaConfig(options)
})

const isAlgolia = computed(() =>
  provider.value === 'algolia' && algoliaValidation.value?.isValid === true
)

// Log warning for invalid Algolia config
if (import.meta.env.DEV) {
  if (provider.value === 'algolia' && !algoliaValidation.value?.isValid) {
    console.warn(
      '[VitePress Theme] Algolia search configured but missing required fields:',
      algoliaValidation.value?.missingFields
    )
  }
}

// Async component loading with error handling
const VPLocalSearchBox = defineAsyncComponent({
  loader: () => import('./VPLocalSearchBox.vue'),
  errorComponent: VPSearchError,
  onError(error, retry, fail) {
    console.error('[VitePress Theme] Failed to load local search:', error)
    fail()
  }
})

const VPAlgoliaSearchBox = defineAsyncComponent({
  loader: () => import('./VPAlgoliaSearchBox.vue'),
  errorComponent: VPSearchError,
  onError(error, retry, fail) {
    console.error('[VitePress Theme] Failed to load Algolia search:', error)
    fail()
  }
})

// #region Algolia Search

const resolvedMode = computed(() => resolveMode(algoliaOptions.value))

const askAiSidePanelConfig = computed(() => {
  if (!resolvedMode.value.useSidePanel) return null
  const askAi = algoliaOptions.value.askAi
  if (!askAi || typeof askAi === 'string') return null
  if (!askAi.sidePanel) return null
  return askAi.sidePanel === true ? {} : askAi.sidePanel
})

const askAiShortcutEnabled = computed(() => {
  return askAiSidePanelConfig.value?.keyboardShortcuts?.['Ctrl/Cmd+I'] !== false
})

type OpenTarget = 'search' | 'askAi' | 'toggleAskAi'
type OpenRequest = { target: OpenTarget; nonce: number }
const openRequest = ref<OpenRequest | null>(null)
let openNonce = 0

// to avoid loading the docsearch js upfront (which is more than 1/3 of the
// payload), we delay initializing it until the user has actually clicked or
// hit the hotkey to invoke it.
const loaded = ref(false)
const actuallyLoaded = ref(false)

onMounted(() => {
  if (!isAlgolia.value) return

  const id = 'VPAlgoliaPreconnect'
  if (document.getElementById(id)) return

  const appId =
    algoliaOptions.value.appId ||
    (typeof algoliaOptions.value.askAi === 'object'
      ? algoliaOptions.value.askAi?.appId
      : undefined)

  if (!appId) return

  const rIC = window.requestIdleCallback || setTimeout
  rIC(() => {
    const preconnect = document.createElement('link')
    preconnect.id = id
    preconnect.rel = 'preconnect'
    preconnect.href = `https://${appId}-dsn.algolia.net`
    preconnect.crossOrigin = ''
    document.head.appendChild(preconnect)
  })
})

if (isAlgolia.value) {
  onKeyStroke('k', (event) => {
    if (
      resolvedMode.value.showKeywordSearch &&
      (event.ctrlKey || event.metaKey)
    ) {
      event.preventDefault()
      loadAndOpen('search')
    }
  })

  onKeyStroke('i', (event) => {
    if (
      askAiSidePanelConfig.value &&
      askAiShortcutEnabled.value &&
      (event.ctrlKey || event.metaKey)
    ) {
      event.preventDefault()
      loadAndOpen('askAi')
    }
  })

  onKeyStroke('/', (event) => {
    if (resolvedMode.value.showKeywordSearch && !isEditingContent(event)) {
      event.preventDefault()
      loadAndOpen('search')
    }
  })
}

function loadAndOpen(target: OpenTarget) {
  if (!loaded.value) {
    loaded.value = true
  }

  // This will either be handled immediately if DocSearch is ready,
  // or queued by the AlgoliaSearchBox until its instances become ready.
  openRequest.value = { target, nonce: ++openNonce }
}

// #endregion

// #region Local Search

const showSearch = ref(false)

// Setup keyboard shortcuts for local search
onMounted(() => {
  if (!isLocal.value) return
})

// Register keyboard shortcuts for local search
onKeyStroke('k', (event) => {
  if (!isLocal.value) return
  if (event.ctrlKey || event.metaKey) {
    event.preventDefault()
    showSearch.value = true
  }
})

onKeyStroke('/', (event) => {
  if (!isLocal.value) return
  if (!isEditingContent(event)) {
    event.preventDefault()
    showSearch.value = true
  }
})

// #endregion

function isEditingContent(event: KeyboardEvent): boolean {
  const element = event.target as HTMLElement
  const tagName = element.tagName

  return (
    element.isContentEditable ||
    tagName === 'INPUT' ||
    tagName === 'SELECT' ||
    tagName === 'TEXTAREA'
  )
}
</script>

<template>
  <div class="VPNavBarSearch">
    <!-- Local Search -->
    <template v-if="provider === 'local'">
      <VPNavBarSearchButton
        :text="algoliaOptions.translations?.button?.buttonText || 'Search'"
        :aria-label="algoliaOptions.translations?.button?.buttonAriaLabel || 'Search'"
        :aria-keyshortcuts="'/ control+k meta+k'"
        @click="showSearch = true"
      />
      <VPLocalSearchBox
        v-if="showSearch"
        @close="showSearch = false"
      />
    </template>

    <!-- Algolia Search - only render if config is valid -->
    <template v-if="isAlgolia">
      <VPNavBarSearchButton
        v-if="resolvedMode.showKeywordSearch"
        :text="algoliaOptions.translations?.button?.buttonText || 'Search'"
        :aria-label="algoliaOptions.translations?.button?.buttonAriaLabel || 'Search'"
        :aria-keyshortcuts="'/ control+k meta+k'"
        @click="loadAndOpen('search')"
      />
      <VPNavBarAskAiButton
        v-if="askAiSidePanelConfig"
        :aria-label="askAiSidePanelConfig.button?.translations?.buttonAriaLabel || 'Ask AI'"
        :aria-keyshortcuts="askAiShortcutEnabled ? 'control+i meta+i' : undefined"
        @click="actuallyLoaded ? loadAndOpen('toggleAskAi') : loadAndOpen('askAi')"
      />
      <VPAlgoliaSearchBox
        v-if="loaded"
        :algolia-options
        :open-request
        @vue:beforeMount="actuallyLoaded = true"
      />
    </template>

    <!-- Algolia configured but invalid config OR no search configured - render nothing -->
  </div>
</template>

<style scoped>
.VPNavBarSearch {
  display: flex;
  align-items: center;
}

@media (min-width: 768px) {
  .VPNavBarSearch {
    gap: 8px;
    flex-grow: 1;
    padding-left: 8px;
  }
}

@media (min-width: 960px) {
  .VPNavBarSearch {
    padding-left: 12px;
  }
}
</style>
