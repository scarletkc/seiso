import sys,io,contextlib,difflib
import review
for arg in sys.argv[1:]:
    ids=range(*map(int,arg.split(':'))) if ':' in arg else [int(arg)]
    for i in ids:
        with contextlib.redirect_stdout(io.StringIO()):fact=review.view(i)
        r,t,frag,raw,heads,attrs,prof=review.target_info(i)
        src=review.blob(r['source'],r['path']);a,b=r['span']['start'],r['span']['end']
        context=src[max(0,a-45):min(len(src),b+45)].decode(errors='replace').replace('\n',' | ')
        wanted=review.vslug(frag)
        matches=[(n,l) for n,l in heads+attrs if review.vslug(l)==wanted or '{#'+wanted+'}' in l]
        if t=='docs/guide/cli.md':matches +=[(n,l) for n,l in review.heading_lines(review.text('vitest','docs/guide/cli-generated.md')) if review.vslug(l)==wanted]
        closest=sorted(heads,key=lambda x:difflib.SequenceMatcher(None,wanted,review.vslug(x[1])).ratio(),reverse=True)[:2]
        print(i,r['path'],f'L{r["diagnostic"]["location"]["row"]}',f'-> {t}#{frag}')
        print('SOURCE',context)
        print('TARGET MATCH',matches if matches else 'NONE; nearest '+str(closest))
