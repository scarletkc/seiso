import review,re,json
fp=[7,8,9,10,11,12,13,14,15,16,17,18,21,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,44,45,46,47,48,49,50,51,52,53,54,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80]
tp={19:'The target has Advanced features and nested/scoped listings, but no Advanced settings heading or explicit advanced-settings id.',20:'The blog setup target has Configuration, Usage, and Customization chapters, but no Advanced settings heading or explicit advanced-settings id.',22:'The privacy target has Cookie consent, Built-in privacy plugin and Custom cookies, but no Advanced settings heading or explicit advanced-settings id.',42:'The logo target now has a single Logo heading; logo-image is absent.',43:'The logo target now has a single Logo heading; logo-icon-bundled is absent.',55:'The grids target has Using card grids and Using generic grids, generating using-card-grids and using-generic-grids; using-grids is absent.',56:'The grids target has Using card grids and Using generic grids, generating using-card-grids and using-generic-grids; using-grids is absent.'}
proofs={26:'Target line153 defines footnote [^7], referenced at line143. Configured footnotes extension uses fn: plus the literal footnote label with UNIQUE_IDS false and default colon separator.',45:'Target line46 defines tab "... or even me" under Anchor links line33. Configured combine_header_slug joins anchor-links, separator -, and the tab slug -or-even-me to generate anchor-links--or-even-me. Static tabbed.py and slugs.py inspection supplies this transform.',46:'Target defines footnote [^1] immediately after source jump link. Configured footnotes extension uses fn: plus literal label 1.',47:'Target defines footnote [^2] immediately after source jump link. Configured footnotes extension uses fn: plus literal label 2.',48:'Target line132 heading Caret, Mark & Tilde generates caret-mark-tilde through configured Python Markdown toc punctuation removal and separator collapse.',49:'Target line132 heading Caret, Mark & Tilde generates caret-mark-tilde through configured Python Markdown toc punctuation removal and separator collapse.',50:'Target line132 heading Caret, Mark & Tilde generates caret-mark-tilde through configured Python Markdown toc punctuation removal and separator collapse.',53:'Target line132 heading Caret, Mark & Tilde generates caret-mark-tilde through configured Python Markdown toc punctuation removal and separator collapse.',54:'Target line103 heading Sub- and superscripts generates sub-and-superscripts through Python Markdown toc separator collapse.'}
dec=[]
for i in sorted(fp+list(tp)):
 r,t,f,raw,heads,attrs,p=review.target_info(i);prefix=f"Source {r['path']} line{r['diagnostic']['location']['row']} links to {t}#{f}. "
 if i in fp:
  proof=proofs.get(i)
  if not proof:
   settings=[(n,l) for n,l in enumerate(raw.splitlines(),1) if 'md:setting '+f+' ' in l]
   options=[(n,l) for n,l in enumerate(raw.splitlines(),1) if f.startswith('+') and 'md:option '+f[1:]+' ' in l]
   ids=[(n,l) for n,l in enumerate(raw.splitlines(),1) if re.search(r'\bid\s*=\s*["\']?'+re.escape(f)+r'(?:["\']|\s|})',l)]
   assert settings or options or ids,(i,f)
   n,l=(settings or options or ids)[0]
   mechanism='pinned shortcodes.py setting() emits the exact heading attribute { #'+f+' }, honored by enabled attr_list' if settings else 'pinned shortcodes.py option() emits the exact link attribute { #'+f+' }, honored by enabled attr_list' if options else 'enabled attr_list preserves the exact explicit id'
   proof=f'Target line{n} {l!r}; {mechanism}.'
  reason=prefix+proof;label='fp'
 else:
  proof='Complete target heading, explicit id, shortcode and include inventory inspected; no configured hook produces the requested absent section.';reason=prefix+tp[i];label='tp'
 d=review.DOCS[(r['source'],t)]
 evidence=f"{proof} Independent contexts/{i:03}.json; target Git blob {d['git_blob']}, SHA256 {d['sha256']}. Pinned mkdocs.yml enables shortcodes.py, attr_list, toc, footnotes, snippets and tabbed (combine_header_slug/lowercase slugify); retained renderer evidence supplies hooks. Static renderer-supplement/inputs.json provides integrity-checked Markdown3.2 and pymdown10.2/10.21 package sources, without executing them. Requirements specify ranges rather than an exact installed site-build version; no rendered build or browser run is claimed."
 dec.append(dict(index=i,label=label,reason=reason,renderer='Configured pinned MkDocs Material site with Python Markdown, attr_list, shortcodes, footnotes and tabbed',evidence=evidence))
(review.OUT/'decisions-material.json').write_text(json.dumps(dec,indent=2)+'\n');review.add(dec)
